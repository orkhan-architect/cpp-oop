#include <iostream>
#include "np6.h"

int main()
{
	Array int_array;

	int_array.malloc_creater();

	std::cout << std::endl;

	int_array.calloc_creater();

	std::cout << std::endl;

	int_array.realloc_creater();

	return 0;
}