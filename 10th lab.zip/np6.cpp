#include <iostream>
#include <cstdlib>
#include "np6.h"

void Array::malloc_creater() {
	unsigned short length = 0;
	std::cout << "Enter the length: ";
	std::cin >> length;

	std::cout << std::endl;

	auto ptr = static_cast<int*>(malloc(length * sizeof(int)));

	if(ptr != nullptr) {
		for (size_t i = 0; i < length; i++) {
			std::cout << "Enter any int number: ";
			std::cin >> *(ptr + i);
		}
	}

	if (ptr != nullptr)
		for (size_t i = 0; i < length; i++)
			std::cout << *(ptr + i) << ' ';

	free(ptr);
}

void Array::calloc_creater() {
	unsigned short length = 0;
	std::cout << "Enter the length: ";
	std::cin >> length;

	std::cout << std::endl;

	auto ptr = static_cast<int*>(calloc(length, sizeof(int)));

	if (ptr != nullptr) {
		for (size_t i = 0; i < length; i++) {
			std::cout << "Enter any int number: ";
			std::cin >> *(ptr + i);
		}
	}

	if (ptr != nullptr)
		for (size_t i = 0; i < length; i++)
			std::cout << *(ptr + i) << ' ';

	free(ptr);
}

void Array::realloc_creater() {
	unsigned short length = 0;
	std::cout << "Enter the length: ";
	std::cin >> length;

	std::cout << std::endl;

	auto ptr = static_cast<int*>(calloc(length, sizeof(int)));

	if (ptr != nullptr) {
		for (size_t i = 0; i < length; i++) {
			std::cout << "Enter any int number: ";
			std::cin >> *(ptr + i);
		}
	}

	if (ptr != nullptr)
		for (size_t i = 0; i < length; i++)
			std::cout << *(ptr + i) << ' ';

	std::cout << std::endl;

	length = 10;
	auto tmp = static_cast<int*>(realloc(ptr, length * sizeof(int)));

	if (tmp != nullptr)
		ptr = tmp;

	if (ptr != nullptr) {
		for (size_t i = 0; i < length; i++) {
			std::cout << "Enter any int number: ";
			std::cin >> *(ptr + i);
		}
	}

	if (ptr != nullptr)
		for (size_t i = 0; i < length; i++)
			std::cout << *(ptr + i) << ' ';

	free(ptr);
}