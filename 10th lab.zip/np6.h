#pragma once

class Array {
public:

	void malloc_creater();
	void calloc_creater();
	void realloc_creater();
};