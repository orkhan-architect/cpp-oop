#include <iostream>
#include "np4.h"

Time::Time() {
	seconds = 0;
}

float Time::sec_in_min(float sec) {
	float minutes = 0;

	minutes = sec / 60;

	return minutes;
}

float Time::sec_in_hours(float sec) {
	float hours = 0;

	hours = sec / 3600;

	return hours;
}

Time& Time::operator++ () {
	this->seconds = this->Get_Seconds() + 1;
	return *this;
}

Time& Time::operator-- () {
	this->seconds = this->Get_Seconds() - 1;
	return *this;
}

Time Time::operator++ (int){
	Time tmp = *this;
	++(*this);
	return tmp;
}

Time Time::operator-- (int) {
	Time tmp = *this;
	--(*this);
	return tmp;
}

bool Time::operator> (const Time& other) {
	if (this->seconds > other.seconds)
		return true;
	else
		return false;
}

bool Time::operator< (const Time& other) {
	if (this->seconds < other.seconds)
		return true;
	else
		return false;
}

bool Time::operator>= (const Time& other) {
	if (this->seconds >= other.seconds)
		return true;
	else
		return false;
}

bool Time::operator<= (const Time& other) {
	if (this->seconds <= other.seconds)
		return true;
	else
		return false;
}

bool Time::operator== (const Time& other) {
	if (this->seconds == other.seconds)
		return true;
	else
		return false;
}

bool Time::operator!= (const Time& other) {
	if (this->seconds != other.seconds)
		return true;
	else
		return false;
}

Time& Time::operator+= (const Time& other) {
	this->seconds += other.seconds;
	return *this;
}

Time& Time::operator-= (const Time& other) {
	this->seconds -= other.seconds;
	return *this;
}

void Time::operator= (Time other) {
	this->seconds = other.seconds;
}