#include <iostream>
#include "np4.h"

std::ostream& operator<< (std::ostream& out, const Time& sec)
{
	out << sec.Get_Seconds();
	return out;
}

std::istream& operator>> (std::istream& in, Time& sec)
{
	unsigned int seconds = 0;
	std::cout << "Enter any integer number bigger than 0: ";
	std::cin >> seconds;

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	sec.Set_Sec(seconds);

	return in;
}

int main()
{
	unsigned short operation = 0;
	bool checking = true;

	float my_minutes = 0, my_hours = 0;

	Time my_time, your_time, tmp_time;

	std::cin >> my_time;
	std::cin >> your_time;

	while (checking) {
		std::cout << std::endl;
		std::cout
			<< "Enter the operation number that you want proceed: " << '\n'
			<< "1. ++prefix" << '\n'
			<< "2. --prefix" << '\n'
			<< "3. postfix++" << '\n'
			<< "4. postfix--" << '\n'
			<< "5. >" << '\n'
			<< "6. <" << '\n'
			<< "7. >=" << '\n'
			<< "8. <=" << '\n'
			<< "9. ==" << '\n'
			<< "10. !=" << '\n'
			<< "11. +=" << '\n'
			<< "12. -=" << '\n'
			<< "13. =" << '\n'
			<< "14. Convert seconds to minutes" << '\n'
			<< "15. Convert seconds to hours" << '\n'
			<< "16. EXIT" << '\n';

		std::cin >> operation;
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (operation)
		{
		case 1:
			std::cout << ++my_time;
			break;
		case 2:
			std::cout << --my_time;
			break;
		case 3:
			std::cout << my_time++;
			break;
		case 4:
			std::cout << my_time--;
			break;
		case 5:
			if (my_time > your_time)
				std::cout << my_time << " is bigger than " << your_time << '\n';
			else
				std::cout << my_time << " is less than or equal to " << your_time << '\n';
			break;
		case 6:
			if (my_time < your_time)
				std::cout << my_time << " is less than " << your_time << '\n';
			else
				std::cout << my_time << " is bigger than or equal to " << your_time << '\n';
			break;
		case 7:
			if (my_time >= your_time)
				std::cout << my_time << " is bigger than or equal to " << your_time << '\n';
			else
				std::cout << my_time << " is less than " << your_time << '\n';
			break;
		case 8:
			if (my_time <= your_time)
				std::cout << my_time << " is less than or equal to " << your_time << '\n';
			else
				std::cout << my_time << " is bigger than " << your_time << '\n';
			break;
		case 9:
			if (my_time == your_time)
				std::cout << my_time << " is equal to " << your_time << '\n';
			else
				std::cout << my_time << " is not equal to " << your_time << '\n';
			break;
		case 10:
			if (my_time != your_time)
				std::cout << my_time << " is not equal to " << your_time << '\n';
			else
				std::cout << my_time << " is equal to " << your_time << '\n';
			break;
		case 11:
			my_time += your_time;
			std::cout << my_time;
			break;
		case 12:
			my_time -= your_time;
			std::cout << my_time;
			break;
		case 13:
			tmp_time = my_time;
			std::cout << tmp_time;
			break;
		case 14:
			my_minutes = my_time.sec_in_min(my_time.Get_Seconds());
			std::cout << my_minutes << " minutes";
			break;
		case 15:
			my_hours = my_time.sec_in_hours(my_time.Get_Seconds());
			std::cout << my_hours << " hours";
			break;
		case 16:
			checking = false;
			break;
		default:
			std::cout << "You are out of range. Try again " << '\n';
			break;
		}
	}
	return 0;
}