#pragma once

class Time {
private:
	unsigned int seconds;

public:
#pragma region Getters_Setters

	unsigned int Get_Seconds() const { return seconds;  }
	void Set_Sec(unsigned int seconds) { this->seconds = seconds; }

#pragma endregion

	Time();

	float sec_in_min(float sec);
	float sec_in_hours(float sec);

#pragma region Operators

	Time& operator++ ();
	Time& operator-- ();
	Time operator++ (int);
	Time operator-- (int);

	bool operator> (const Time& other);
	bool operator< (const Time& other);
	bool operator>= (const Time& other);
	bool operator<= (const Time& other);
	bool operator== (const Time& other);
	bool operator!= (const Time& other);

	Time& operator+= (const Time& other);
	Time& operator-= (const Time& other);
	void operator= (Time other);

#pragma endregion
};