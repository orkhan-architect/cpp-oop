#pragma once

class Airplane {
private:
	char* type;
	int passengers;

public:
#pragma region Getters
	char* GetType() const { return type; }
	int GetPasCount() const { return passengers; }
#pragma endregion

	bool operator==(const Airplane& other);
	bool operator>(const Airplane& other);
	bool operator<(const Airplane& other);
	Airplane& operator++();
	Airplane& operator--();
	Airplane operator++(int);
	Airplane operator--(int);

	Airplane();
	Airplane(int passengers);
	Airplane(char* type, int passengers);
	~Airplane();
};
