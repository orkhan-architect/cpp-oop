#include <iostream>
#include "oop1.h"

std::ostream& operator<< (std::ostream& out, const Airplane& passengers)
{
	out << passengers.GetPasCount() << '\n';
	return out;
}

int main()
{
	Airplane airplane1(new char[] { "Airbus A333-300" }, 400);
	Airplane airplane2(new char[] { "Boeing 777-300" }, 550);
	Airplane airplane3(new char[] { "Airbus A333-300" }, 400);

	if (airplane1 == airplane2)
		std::cout << "they are same airplanes" << '\n';
	else
		std::cout << "they are different airplanes" << '\n';

	Airplane airplain4(5);
	std::cout << ++airplain4;
	std::cout << ++airplain4;
	std::cout << --airplain4;
	std::cout << --airplain4;

	if (airplane1 > airplane2)
		std::cout << "passengers count of first airplane is bigger than the second" << '\n';
	else
		std::cout << "passengers count of second airplane is bigger than the first" << '\n';

	if (airplane1 < airplane2)
		std::cout << "passengers count of first airplane is less than the second" << '\n';
	else
		std::cout << "passengers count of second airplane is less than the first" << '\n';

	return 0;
}