#include <iostream>
#include "oop1.h"

bool Airplane::operator==(const Airplane& other)
{
	bool type_compare = strcmp(this->type, other.type) == 0;

	if (type_compare == true)
		return true;
	else
		return false;
}

bool Airplane::operator>(const Airplane& other) {
	if (this->passengers > other.passengers)
		return true;
	else
		return false;
}

bool Airplane::operator<(const Airplane& other) {
	if (this->passengers < other.passengers)
		return true;
	else
		return false;
}

Airplane& Airplane::operator++() {
	this->passengers = this->GetPasCount() + 1;
	return *this;
}

Airplane& Airplane::operator--() {
	this->passengers = this->GetPasCount() - 1;
	return *this;
}

Airplane Airplane::operator++(int) {
	Airplane tmp = *this;
	++(*this);
	return tmp;
}

Airplane Airplane::operator--(int) {
	Airplane tmp = *this;
	--(*this);
	return tmp;
}

Airplane::Airplane() {
	type = new char[20]{};
	passengers = 0;
}

Airplane::Airplane(int passengers) {
	this->passengers = passengers;
}

Airplane::Airplane(char* type, int passengers) {
	this->type = type;
	this->passengers = passengers;
}

Airplane::~Airplane() {
	delete[] type;
}