#include <iostream>
#include "oop1.h"

int main()
{
	Student student1;

	char* name1 = new char[] { "Orkhan" };
	char* surname1 = new char[] { "Tukanov" };
	char* patronymic1 = new char[] { "Muhammed" };
	char* gender1 = new char[] { "male" };
	char* city1 = new char[] { "Baki" };
	char* country1 = new char[] { "Azerbaijan" };
	unsigned short age1 = 34;
	student1.pers_input(name1, surname1, patronymic1, gender1, city1, country1, age1);

	char* university1 = new char[] { "ASEU" };
	char* uni_city1 = new char[] { "Baki" };
	char* uni_country1 = new char[] { "Azerbaijan" };
	unsigned short group_num1 = 81;
	student1.stu_input(university1, uni_city1, uni_country1, group_num1);

	Lector welcome;

	Lector lector1(11);

	char* name2 = new char[] { "Elvin" };
	char* surname2 = new char[] { "Azimov" };
	char* patronymic2 = new char[] { "....." };
	char* gender2 = new char[] { "male" };
	char* city2 = new char[] { "Baki" };
	char* country2 = new char[] { "Azerbaijan" };
	unsigned short age2 = 19;
	lector1.pers_input(name2, surname2, patronymic2, gender2, city2, country2, age2);

	char* subject = new char[] { "Economy" };
	unsigned short absence = 3;
	unsigned short activity = 11;	
	lector1.lec_input(subject, absence, activity);

	lector1.exam_access();
	std::cout << std::endl;

	std::cout << "This info belongs to student" << std::endl;
	student1.pers_print();
	std::cout << std::endl;
	std::cout << "This info belongs to lector" << std::endl;
	lector1.pers_print();
	std::cout << std::endl;
	student1.stu_print();
	std::cout << std::endl;
	lector1.lec_print();
	std::cout << std::endl;

	return 0;
}