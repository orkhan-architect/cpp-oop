#include <iostream>
#include <fstream>
#include <string>
#include "lab16.h"

int main()
{
	int cislitel_1, znamenatel_1, cislitel_2, znamenatel_2;
	unsigned short operation;
	bool checking = true;

	std::ofstream out;
	out.open("fraction_oper.txt");
	if (out.is_open())
		out << "Welcome to fraction operations" << "\n\n";
	out.close();

	while (checking) {
		// first fraction
		std::cout << "Enter any integer number for numerator: ";
		std::cin >> cislitel_1;

		std::cout << "Enter any integer number for denominator, not only zero: ";
		std::cin >> znamenatel_1;
		while (znamenatel_1 == 0) {
			std::cout << "Try again. You can not divide to zero: ";
			std::cin >> znamenatel_1;
		}

		Fraction fraction_1(cislitel_1, znamenatel_1);

		int filter_1 = fraction_1.GCD(fraction_1.Get_Numerator(), fraction_1.Get_Deniminator());
		fraction_1.cleaner(filter_1);

		/*
		You can check code with various ways:
		result = 5 / 5
		result = -5 / -5

		result = 6 / 2
		result = -6 / 2
		result = 6 / -2

		result = 2 / 6
		result = -2 / 6
		result = 2 / -6
		*/
		fraction_1.print();

		std::cout << std::endl;

		// second fraction
		std::cout << "Enter any integer number for numerator: ";
		std::cin >> cislitel_2;

		std::cout << "Enter any integer number for denominator, not only zero: ";
		std::cin >> znamenatel_2;
		while (znamenatel_2 == 0) {
			std::cout << "Try again. You can not divide to zero: ";
			std::cin >> znamenatel_2;
		}

		Fraction fraction_2(cislitel_2, znamenatel_2);

		int filter_2 = fraction_2.GCD(fraction_2.Get_Numerator(), fraction_2.Get_Deniminator());
		fraction_2.cleaner(filter_2);
		/*
		You can check code with various ways:
		result = 5 / 5
		result = -5 / -5

		result = 6 / 2
		result = -6 / 2
		result = 6 / -2

		result = 2 / 6
		result = -2 / 6
		result = 2 / -6
		*/
		fraction_2.print();

		std::cout
			<< '\n' << "Enter the operation number that you want proceed: " << '\n'
			<< "1. ADDITION" << '\n'
			<< "2. SUBTRACTION" << '\n'
			<< "3. MULTIPLICATION" << '\n'
			<< "4. DIVISION" << '\n'
			<< "5. EXIT" << '\n';
		std::cin >> operation;
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (operation)
		{
		case 1:
			fraction_1 + fraction_2;
			std::cout << '\n';
			break;
		case 2:
			fraction_1 - fraction_2;
			std::cout << '\n';
			break;
		case 3:
			fraction_1 * fraction_2;
			std::cout << '\n';
			break;
		case 4:
			fraction_1 / fraction_2;
			std::cout << '\n';
			break;
		case 5:
			checking = false;
			break;
		default:
			std::cout << "You are out of range, try again." << '\n';
			break;
		}
	}

	std::string text_buffer;

	std::ifstream in;
	in.open("fraction_oper.txt");

	if (in.is_open())
		while (getline(in, text_buffer))
			std::cout << text_buffer << std::endl;

	in.close();

	return 0;
}