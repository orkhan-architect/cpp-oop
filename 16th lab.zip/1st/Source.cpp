#include <iostream>
#include <fstream>
#include <string>
#include "lab16.h"

int main()
{
	//std::cout << "It is students field" << "\n\n";

	char* p_name = new char[] { "Orkhan" };
	char* p_surname = new char[] { "Tukanov" };
	char* p_patronymic = new char[] { "Muhammed" };
	char* p_gender = new char[] { "male" };
	unsigned short p_age = 34;

	char* st_univ = new char[] { "ASEU" };
	char* st_uni_city = new char[] { "Baki" };
	char* st_uni_count = new char[] { "Azerbaijan" };
	unsigned short st_group_num = 33;

	Student student1(p_name, p_surname, p_patronymic, p_gender, p_age, st_univ, st_uni_city, st_uni_count, st_group_num);
	//student1.print();

	//std::cout << std::endl;
	//std::cout << "It is lectors field" << "\n\n";

	char* l_name = new char[] { "Elvin" };
	char* l_surname = new char[] { "Azimov" };
	char* l_patronymic = new char[] { "..." };
	char* l_gender = new char[] { "male" };
	unsigned short l_age = 19;

	char* l_subject = new char[] { "Python" };

	Lector lector1(l_name, l_surname, l_patronymic, l_gender, l_age, l_subject);
	//lector1.print();

	std::string text_buffer;

	std::ifstream in;
	in.open("student_lector.txt");

	if (in.is_open())
		while (getline(in, text_buffer))
			std::cout << text_buffer << std::endl;

	in.close();

	return 0;
}