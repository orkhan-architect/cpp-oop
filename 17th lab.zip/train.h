#pragma once
#include <iostream>
#include <string>

class Tr_Time {
private:
	size_t day;
	size_t month;
	size_t year;
	size_t minute;
	size_t hour;

public:
	Tr_Time() 
		: day(1), month(1), year(1900), minute(0), hour(0) {
	}

	Tr_Time(size_t t_day, size_t t_month, size_t t_year, size_t t_minute, size_t t_hour)
		: day(t_day), month(t_month), year(t_year), minute(t_minute), hour(t_hour) {
	}

	friend std::ostream& operator<<(std::ostream& out, const Tr_Time& send_time) {
		out << send_time.day << "." << send_time.month << "." << send_time.year << ", " << send_time.hour << ":" << send_time.minute << '\n';

		return out;
	}
};

class Train {
private:
	size_t number;
	std::string destination;
	Tr_Time train_time;

public:
	Train(const size_t& t_number, const std::string& t_destination, const Tr_Time& t_time)
		: number(t_number), destination(t_destination), train_time(t_time) {
	}

	friend std::ostream& operator<<(std::ostream& out, const Train& voyage_train) {
		out << voyage_train.number << " numbered train arrived in " << voyage_train.destination << " in " << voyage_train.train_time << '\n';

		return out;
	}
};