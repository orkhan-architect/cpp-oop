#include <iostream>
#include <string>
#include <vector>
#include "train.h"

int main()
{
	size_t train_number_1 = 152, train_number_2 = 98;
	std::string des_point_1 = "Canada", des_point_2 = "Mexico";

	std::vector <Train> trains;

	Train* t1 = new Train(train_number_1, des_point_1, Tr_Time(15, 11, 2021, 15, 30));
	Train* t2 = new Train(train_number_2, des_point_2, Tr_Time(25, 11, 2021, 20, 15));

	trains.push_back(*t1);
	trains.push_back(*t2);

	for (size_t i = 0; i < trains.size(); i++)
		std::cout << trains[i];

	size_t tr_index;
	std::cout << "Please enter which train you want see: ";
	std::cin >> tr_index;

	std::cout << trains.at(tr_index);

	return 0;
}