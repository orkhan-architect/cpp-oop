#include <iostream>
#include <fstream>
#include "14hw.h"

int main()
{
	int length = 0, number = 1;

	std::string co_name = "none", co_owner = "none", co_phone = "none", co_address = "none", co_activity = "none";
	std::cout << "Enter the count of companies -> ";
	std::cin >> length;
	while (length <= 0 || length > 20000) {
		std::cout << "Try again, your diapason must be between 0-20000 -> ";
		std::cin >> length;
	}

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	Handbook* companies = new Handbook[length]{};
	for (size_t i = 0; i < length; i++)	{
		std::cout << "Enter company name: ";
		getline(std::cin, co_name);

		std::cout << "Enter company owner: ";
		getline(std::cin, co_owner);

		std::cout << "Enter company phone: ";
		getline(std::cin, co_phone);

		std::cout << "Enter company address: ";
		getline(std::cin, co_address);

		std::cout << "Enter company activity type: ";
		getline(std::cin, co_activity);

		companies[i].fill_handbook(co_name, co_owner, co_phone, co_address, co_activity, number);
		number++;

		std::cout << std::endl;
	}

	companies->fill_array(companies, length);

	int operation = 0;
	bool checking = true;
	std::string searched = "none";

	while (checking) {
		std::cout
			<< "Enter the operation number that you want proceed" << '\n'
			<< "1. Search company name" << '\n'
			<< "2. Search owner" << '\n'
			<< "3. Search phone" << '\n'
			<< "4. Search activity type" << '\n'
			<< "5. Show log history" << '\n'
			<< "6. EXIT" << '\n';

		std::cin >> operation;
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (operation) {
		case 1:
			std::cout << "Enter searching element: ";
			getline(std::cin, searched);
			companies->search_by_comp_name(searched);
			break;
		case 2:
			std::cout << "Enter searching element: ";
			getline(std::cin, searched);
			companies->search_by_owner(searched);
			break;
		case 3:
			std::cout << "Enter searching element: ";
			getline(std::cin, searched);
			companies->search_by_phone(searched);
			break;
		case 4:
			std::cout << "Enter searching element: ";
			getline(std::cin, searched);
			companies->search_by_activity(searched);
			break;
		case 5:
			companies->show_log_history();
			break;
		case 6:
			checking = false;
			break;
		default:
			std::cout << "You are out of the range. Try again." << std::endl;
			break;
		}
	}

	return 0;
}