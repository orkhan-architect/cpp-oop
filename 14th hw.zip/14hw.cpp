#include <iostream>
#include <fstream>
#include "14hw.h"

Handbook::Handbook() {
	company_name = "none";
	owner = "none";
	phone_number = "none";
	address = "none";
	activity_type = "none";
}

void Handbook::fill_handbook(std::string company_name, std::string owner, std::string phone_number, std::string address, std::string activity_type, int number) {
	this->company_name = company_name;
	this->owner = owner;
	this->phone_number = phone_number;
	this->address = address;
	this->activity_type = activity_type;

	std::ofstream out;
	out.open("handbook.txt", std::ios::app);

	if (out.is_open()) {
		out << number <<". company" << '\n'
			<< "Company name is:" << "\t\t" << company_name << '\n'
			<< "Company owner is:" << "\t\t" << owner << '\n'
			<< "Company phone number is:" << '\t' << phone_number << '\n'
			<< "Company address is:" << "\t\t" << address << '\n'
			<< "Company activity number is:" << '\t' << activity_type << "\n\n";
	}

	out.close();
}

void Handbook::fill_array(Handbook* h_array, unsigned short len_array) {
	this->handbook_array = h_array;
	this->array_length = len_array;
}

void Handbook::show_element() const {
	std::cout << "Found company for searched element" << '\n'
		<< "Company name is:" << "\t\t" << company_name << '\n'
		<< "Company owner is:" << "\t\t" << owner << '\n'
		<< "Company phone number is:" << '\t' << phone_number << '\n'
		<< "Company address is:" << "\t\t" << address << '\n'
		<< "Company activity number is:" << '\t' << activity_type << '\n';
}

void Handbook::show_log_history() {
	std::string text_buffer;

	std::ifstream in;
	in.open("handbook.txt");

	if (in.is_open())
		while (getline(in, text_buffer))
			std::cout << text_buffer << std::endl;

	in.close();
}

void Handbook::search_by_comp_name(std::string comp_name) {
	for (size_t i = 0; i < array_length; i++) {
		if (handbook_array[i].company_name.compare(comp_name) == 0) {
			handbook_array[i].show_element();

			std::ofstream out;
			out.open("handbook.txt", std::ios::app);

			if (out.is_open()) {
				out << "Found company for searched name element" << '\n'
					<< "Company name is:" << "\t\t" << handbook_array[i].Get_Name() << '\n'
					<< "Company owner is:" << "\t\t" << handbook_array[i].Get_Owner() << '\n'
					<< "Company phone number is:" << '\t' << handbook_array[i].Get_Phone() << '\n'
					<< "Company address is:" << "\t\t" << handbook_array[i].Get_Address() << '\n'
					<< "Company activity number is:" << '\t' << handbook_array[i].Get_Activity() << "\n\n";
			}

			out.close();

			break;
		}
		else if (i == array_length - 1 && handbook_array[i].company_name.compare(comp_name) != 0) {
			std::cout << "There is no company for your searched name element" << '\n';
		}
	}
}

void Handbook::search_by_owner(std::string comp_owner) {
	for (size_t i = 0; i < array_length; i++) {
		if (handbook_array[i].owner.compare(comp_owner) == 0) {
			handbook_array[i].show_element();

			std::ofstream out;
			out.open("handbook.txt", std::ios::app);

			if (out.is_open()) {
				out << "Found company for searched owner element" << '\n'
					<< "Company name is:" << "\t\t" << handbook_array[i].Get_Name() << '\n'
					<< "Company owner is:" << "\t\t" << handbook_array[i].Get_Owner() << '\n'
					<< "Company phone number is:" << '\t' << handbook_array[i].Get_Phone() << '\n'
					<< "Company address is:" << "\t\t" << handbook_array[i].Get_Address() << '\n'
					<< "Company activity number is:" << '\t' << handbook_array[i].Get_Activity() << "\n\n";
			}

			out.close();

			break;
		}
		else if (i == array_length - 1 && handbook_array[i].owner.compare(comp_owner) != 0) {
			std::cout << "There is no company for your searched owner element" << '\n';
		}
	}
}

void Handbook::search_by_phone(std::string comp_phone) {
	for (size_t i = 0; i < array_length; i++) {
		if (handbook_array[i].phone_number.compare(comp_phone) == 0) {
			handbook_array[i].show_element();

			std::ofstream out;
			out.open("handbook.txt", std::ios::app);

			if (out.is_open()) {
				out << "Found company for searched phone element" << '\n'
					<< "Company name is:" << "\t\t" << handbook_array[i].Get_Name() << '\n'
					<< "Company owner is:" << "\t\t" << handbook_array[i].Get_Owner() << '\n'
					<< "Company phone number is:" << '\t' << handbook_array[i].Get_Phone() << '\n'
					<< "Company address is:" << "\t\t" << handbook_array[i].Get_Address() << '\n'
					<< "Company activity number is:" << '\t' << handbook_array[i].Get_Activity() << "\n\n";
			}

			out.close();

			break;
		}
		else if (i == array_length - 1 && handbook_array[i].phone_number.compare(comp_phone) != 0) {
			std::cout << "There is no company for your searched phone element" << '\n';
		}
	}
}

void Handbook::search_by_activity(std::string comp_activity) {
	for (size_t i = 0; i < array_length; i++) {
		if (handbook_array[i].activity_type.compare(comp_activity) == 0) {
			handbook_array[i].show_element();

			std::ofstream out;
			out.open("handbook.txt", std::ios::app);

			if (out.is_open()) {
				out << "Found company for searched activity element" << '\n'
					<< "Company name is:" << "\t\t" << handbook_array[i].Get_Name() << '\n'
					<< "Company owner is:" << "\t\t" << handbook_array[i].Get_Owner() << '\n'
					<< "Company phone number is:" << '\t' << handbook_array[i].Get_Phone() << '\n'
					<< "Company address is:" << "\t\t" << handbook_array[i].Get_Address() << '\n'
					<< "Company activity number is:" << '\t' << handbook_array[i].Get_Activity() << "\n\n";
			}

			out.close();

			break;
		}
		else if (i == array_length - 1 && handbook_array[i].activity_type.compare(comp_activity) != 0) {
			std::cout << "There is no company for your searched activity element" << '\n';
		}
	}
}