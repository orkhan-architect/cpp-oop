#pragma once
#include <string>

class Handbook {
private:
	std::string company_name;
	std::string owner;
	std::string phone_number;
	std::string address;
	std::string activity_type;

	Handbook* handbook_array;
	unsigned short array_length;

public:
	Handbook();

	std::string Get_Name() const { return company_name; }
	std::string Get_Owner() const { return owner; }
	std::string Get_Phone() const { return phone_number; }
	std::string Get_Address() const { return address; }
	std::string Get_Activity() const { return activity_type; }

#pragma region METHODS
	void fill_handbook(std::string, std::string, std::string, std::string, std::string, int);
	void fill_array(Handbook*, unsigned short);
	void show_element() const;
	void search_by_comp_name(std::string);
	void search_by_owner(std::string);
	void search_by_phone(std::string);
	void search_by_activity(std::string);
	void show_log_history();
#pragma endregion
};