#pragma once

class Pets {
private:
	char* name;
	char* breed;
	char* feeding;
	char* sound;
	unsigned short age;

public:
#pragma region Getters

	char* Get_Name() const { return name; }
	char* Get_Breed() const { return breed; }
	char* Get_Feeding() const { return feeding; }
	char* Get_Sound() const { return sound; }
	unsigned short Get_Age() const { return age; }

#pragma endregion

	Pets();
	Pets(char*, char*, char*, char*, unsigned short);
	~Pets();

	virtual void print() = 0;
	virtual void eat(char* meal) = 0;

#pragma region Operators

	bool operator> (const Pets& other);
	bool operator< (const Pets& other);
	bool operator== (const Pets& other);

#pragma endregion
};

class Dog : public Pets {
private:
	bool chasing;

public:
#pragma region Getters

	bool Get_Chasing() const { return chasing; }

#pragma endregion

	Dog();
	Dog(const Dog& copy);
	Dog(char* name, char* breed, char* feeding, char* sound, unsigned short age, bool chasing) : Pets(name, breed, feeding, sound, age) {
		this->chasing = chasing;

		std::cout << "About dog ---------------" << "\n\n";
	}

	void print() override;
	void eat(char* meal) override;
};

class Cat : public Pets {
private:
	bool pantingless;
	
public:
#pragma region Getters

	bool Get_Pantingless() const { return pantingless; }

#pragma endregion

	Cat();
	Cat(const Cat& copy);
	Cat(char* name, char* breed, char* feeding, char* sound, unsigned short age, bool pantingless) : Pets(name, breed, feeding, sound, age) {
		this->pantingless = pantingless;

		std::cout << "About cat ---------------" << "\n\n";
	}

	void print() override;
	void eat(char* meal) override;
};

class Parrot : public Pets {
private:
	bool flying;

public:
#pragma region Getters

	bool Get_Flying() const { return flying; }

#pragma endregion

	Parrot();
	Parrot(const Parrot& copy);
	Parrot(char* name, char* breed, char* feeding, char* sound, unsigned short age, bool flying) : Pets(name, breed, feeding, sound, age) {
		this->flying = flying;

		std::cout << "About parrot ---------------" << "\n\n";
	}

	void print() override;
	void eat(char* meal) override;
};