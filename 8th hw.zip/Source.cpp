#include <iostream>
#include "np5.h"

int main()
{
	char* dog_name = new char [] { "Rex" };
	char* dog_breed = new char [] { "shepherd" };
	char* dog_feeding = new char [] { "predator" };
	char* dog_sound = new char [] { "barking" };
	unsigned short dog_age = 3;
	bool dog_chasing = true;
	char* dog_meal = new char [] { "Chappi" };

	Dog dog_1(dog_name, dog_breed, dog_feeding, dog_sound, dog_age, dog_chasing);
	dog_1.print();
	dog_1.eat(dog_meal);

	std::cout << std::endl;

	char* cat_name = new char [] { "Syndie" };
	char* cat_breed = new char [] { "siam" };
	char* cat_feeding = new char [] { "predator" };
	char* cat_sound = new char [] { "meowing" };
	unsigned short cat_age = 2;
	bool cat_pantingless = false;
	char* cat_meal = new char [] { "fish" };

	Cat cat_1(cat_name, cat_breed, cat_feeding, cat_sound, cat_age, cat_pantingless);
	cat_1.print();
	cat_1.eat(cat_meal);

	std::cout << std::endl;

	char* bird_name = new char [] { "Chicky" };
	char* bird_breed = new char [] { "cacadu" };
	char* bird_feeding = new char [] { "herbivorous" };
	char* bird_sound = new char [] { "tweeting" };
	unsigned short bird_age = 1;
	bool bird_flying = true;
	char* bird_meal = new char [] { "seed" };

	Parrot bird_1(bird_name, bird_breed, bird_feeding, bird_sound, bird_age, bird_flying);
	bird_1.print();
	bird_1.eat(bird_meal);

	std::cout << std::endl;

	if (dog_1 > cat_1)
		std::cout << "This dog is older than the cat";
	else
		std::cout << "This cat is older than the dog";

	std::cout << std::endl;

	if (cat_1 < bird_1)
		std::cout << "This parrot is older than the cat";
	else
		std::cout << "This cat is older than the parrot";

	std::cout << std::endl;

	return 0;
}