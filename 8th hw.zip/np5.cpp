#include <iostream>
#include "np5.h"

Pets::Pets() {
	name = nullptr;
	breed = nullptr;
	feeding = nullptr;
	sound = nullptr;
	age = 0;
}

Pets::Pets(char* name, char* breed, char* feeding, char* sound, unsigned short age) {
	this->name = name;
	this->breed = breed;
	this->feeding = feeding;
	this->sound = sound;
	this->age = age;
}

Pets::~Pets() {
	delete this->name;
	delete this->breed;
	delete this->feeding;
	delete this->sound;
}

Dog::Dog() {
	chasing = true;
}

Dog::Dog(const Dog& copy) {
	this->chasing = copy.chasing;
}

Cat::Cat() {
	pantingless = true;
}

Cat::Cat(const Cat& copy) {
	this->pantingless = copy.pantingless;
}

Parrot::Parrot() {
	flying = true;
}

Parrot::Parrot(const Parrot& copy) {
	this->flying = copy.flying;
}

void Dog::print() {
	std::cout
		<< "Name is:" << "\t\t" << Get_Name() << '\n'
		<< "Breed is:" << "\t\t" << Get_Breed() << '\n'
		<< "Feeding is:" << "\t\t" << Get_Feeding() << '\n'
		<< "Sound is:" << "\t\t" << Get_Sound() << '\n'
		<< "Age is:" << "\t\t\t" << Get_Age() << '\n';

	if (chasing == true)
		std::cout << "This dog can chase traces" << '\n';
	else
		std::cout << "This dog can not chase traces" << '\n';
}

void Dog::eat(char* meal) {
	std::cout << "This dog loves to eat " << meal << '\n';
}

void Cat::print() {
	std::cout
		<< "Name is:" << "\t\t" << Get_Name() << '\n'
		<< "Breed is:" << "\t\t" << Get_Breed() << '\n'
		<< "Feeding is:" << "\t\t" << Get_Feeding() << '\n'
		<< "Sound is:" << "\t\t" << Get_Sound() << '\n'
		<< "Age is:" << "\t\t\t" << Get_Age() << '\n';

	if (pantingless == true)
		std::cout << "This cat is pantingless cat" << '\n';
	else
		std::cout << "This cat is not pantingless cat" << '\n';
}

void Cat::eat(char* meal) {
	std::cout << "This cat loves to eat " << meal << '\n';
}

void Parrot::print() {
	std::cout
		<< "Name is:" << "\t\t" << Get_Name() << '\n'
		<< "Breed is:" << "\t\t" << Get_Breed() << '\n'
		<< "Feeding is:" << "\t\t" << Get_Feeding() << '\n'
		<< "Sound is:" << "\t\t" << Get_Sound() << '\n'
		<< "Age is:" << "\t\t\t" << Get_Age() << '\n';

	if (flying == true)
		std::cout << "This parrot can fly" << '\n';
	else
		std::cout << "This parrot can not fly" << '\n';
}

void Parrot::eat(char* meal) {
	std::cout << "This parrot loves to eat " << meal << '\n';
}

bool Pets::operator> (const Pets& other) {
	if (this->age > other.age)
		return true;
	else
		return false;
}

bool Pets::operator< (const Pets& other) {
	if (this->age < other.age)
		return true;
	else
		return false;
}

bool Pets::operator== (const Pets& other) {
	if (this->age == other.age)
		return true;
	else
		return false;
}