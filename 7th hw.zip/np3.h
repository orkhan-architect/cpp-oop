#pragma once

class Printer {
private:
	char** clients;
	char** clients_priority;
	unsigned short cartridge_capacity;
	unsigned short tray_capacity;
	unsigned short clients_count;

	unsigned short print_count;
	Printer* next;

public:
#pragma region Getters
	char** Get_Clients() const { return clients; }
	char** Get_Priority() const { return clients_priority; }
	unsigned short Get_Cartridge() const { return cartridge_capacity; }
	unsigned short Get_Tray() const { return tray_capacity; }
	unsigned short Get_Client_Count() const { return clients_count; }

	unsigned short Get_Print_Count() const { return print_count; }
	Printer* Get_next() const { return next; }
#pragma endregion

	Printer();
	~Printer();

	void users_count();
	void client_and_priority();
	void change_cartridge();
	void fill_tray();
	void print_user() const;
	void change_user();
	void change_priority();
	void in_sesion();
	void show_log();
};