#include <iostream>
#include <time.h>
#include <stdlib.h>
#include "np3.h"

Printer::Printer() {
	clients = nullptr;
	clients_priority = nullptr;
	cartridge_capacity = 1500;
	tray_capacity = 100;
	clients_count = 0;

	print_count = 0;
	next = nullptr;
}

Printer::~Printer() {
	delete clients;
	delete clients_priority;
	delete next;
}

void Printer::users_count() {
	std::cout << "The first of all, you must set the count of clients: ";
	std::cin >> clients_count;
	while (clients_count <= 0 || clients_count > 5) {
		std::cout << "Your count of clients must be between 1-5: ";
		std::cin >> clients_count;
	}

	std::cout << std::endl;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
}

void Printer::client_and_priority() {
	this->clients = new char* [clients_count] {};
	this->clients_priority = new char* [clients_count] {};

	for (size_t i = 0; i < clients_count; i++) {
		clients[i] = new char[10]{};
		std::cout << "Enter " << i + 1 << ". client name: ";
		gets_s(clients[i], 10);

		clients_priority[i] = new char[5]{};
		std::cout << "Enter " << i + 1 << ". client priority. Write high or low: ";
		gets_s(clients_priority[i], 5);

		std::cout << std::endl;
	}
}

void Printer::change_cartridge() {
	char decision = 'N';
	std::cout
		<< "You can print " << cartridge_capacity << " papers with this cartridge." << '\n'
		<< "Do you want change current cartridge. Make your decision -> Y/N" << '\n';
	std::cin >> decision;

	std::cout << std::endl;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
	
	if (decision == 'Y')
		cartridge_capacity = 1500;
}

void Printer::fill_tray() {
	unsigned short loaded_paper, estimated;

	estimated = 100 - tray_capacity;

	std::cout
		<< "You have " << tray_capacity << " papers in the tray." << '\n'
		<< "Just know. You can fill tray till 100 papers" << '\n';

	std::cout << "Enter the count of the loading paper: ";
	std::cin >> loaded_paper;

	while (loaded_paper > estimated) {
		std::cout << "Try again, you can add " << estimated << " papers in your tray. Know it: ";
		std::cin >> loaded_paper;
	}

	tray_capacity += loaded_paper;

	std::cout << std::endl;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
}

void Printer::print_user() const {
	std::cout << "CLIENTS" << "\t\t\t" << "PRIORITY" << '\n';
	for (size_t i = 0; i < clients_count; i++) {
		std::cout << i+1 << ". " << clients[i] << "\t\t" << clients_priority[i] << '\n';
	}
	std::cout << std::endl;
}

void Printer::change_user() {
	unsigned short user_number;

	print_user();
	
	std::cout << "Enter the number of the client that you want change: ";
	std::cin >> user_number;

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	user_number--;

	std::cout << "Enter the name of the new client that you are going to change: ";
	clients[user_number] = new char[10]{};
	gets_s(clients[user_number], 10);
}

void Printer::change_priority() {
	unsigned short user_number;

	print_user();

	std::cout << "Enter the number of the client that you want change: ";
	std::cin >> user_number;

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	user_number--;

	std::cout << "Enter the new priority (low or high) of this client: ";
	clients_priority[user_number] = new char[5]{};
	gets_s(clients_priority[user_number], 5);
}

void Printer::in_sesion() {

	unsigned short my_count = clients_count;
	unsigned short step = 0;

	struct tm newtime;
	__time64_t long_time;

	char** timebuf = new char* [my_count] {};
	char** filebuf = new char* [my_count] {};

	for (size_t i = 0; i < my_count; i++) {
		timebuf[i] = new char[26]{};
		filebuf[i] = new char[5]{};
	}

	Printer** my_node = new Printer* [my_count + 1];
	for (size_t i = 0; i < my_count; i++)
		my_node[i + 1] = new Printer();

	FILE* files;
	fopen_s(&files, "info.txt", "a");

	for (size_t i = 0; i < my_count; i++) {
		if (strcmp(clients_priority[i], "high") == 0) {
			std::cout << "Enter the print count for " << i + 1 << ". client: ";
			std::cin >> my_node[step + 1]->print_count;
			if (my_node[step + 1]->print_count <= cartridge_capacity && 
				my_node[step + 1]->print_count <= tray_capacity) {

				_time64(&long_time);
				_localtime64_s(&newtime, &long_time);
				asctime_s(timebuf[step], 26, &newtime);

				_itoa_s(my_node[step + 1]->print_count, filebuf[step], 5, 10);
				if (files != nullptr) {
					fputs(filebuf[step], files);
					fputs(" papers were printed by ", files);
					fputs(clients[i], files);
					fputs(". Print date is ", files);
					fputs(timebuf[step], files);
					fputs("\n-----------------------\n", files);
				}

				cartridge_capacity -= my_node[step + 1]->print_count;
				tray_capacity -= my_node[step + 1]->print_count;

				std::cout << "\n ----cartridge capacity remains " << cartridge_capacity << " papers." << '\n';
				std::cout << "\n ----tray capacity remains " << tray_capacity << " papers." << '\n';

				step++;
			}
			else {
				std::cout << "Please check your cartridge or tray." << "\n\n";
			}
		}
	}

	for (size_t i = 0; i < my_count; i++) {
		if (strcmp(clients_priority[i], "low") == 0) {
			std::cout << "Enter the print count for " << i + 1 << ". client: ";
			std::cin >> my_node[step + 1]->print_count;
			if (my_node[step + 1]->print_count <= cartridge_capacity &&
				my_node[step + 1]->print_count <= tray_capacity) {

			_time64(&long_time);
			_localtime64_s(&newtime, &long_time);
			asctime_s(timebuf[step], 26, &newtime);

			_itoa_s(my_node[step + 1]->print_count, filebuf[step], 5, 10);
			if (files != nullptr) {
				fputs(filebuf[step], files);
				fputs(" papers were printed by ", files);
				fputs(clients[i], files);
				fputs(". Print date is ", files);
				fputs(timebuf[step], files);
				fputs("\n-----------------------\n", files);
			}

			cartridge_capacity -= my_node[step + 1]->print_count;
			tray_capacity -= my_node[step + 1]->print_count;

			std::cout << "\n -----cartridge capacity remains " << cartridge_capacity << " papers." << '\n';
			std::cout << "\n -----tray capacity remains " << tray_capacity << " papers." << '\n';

			step++;
			}
			else {
				std::cout 
					<< "Please check your cartridge or tray." << "\n\n";
			}
		}
	}

	if (files != nullptr)
		fclose(files);

	for (size_t i = 0; i < my_count; i++)
		my_node[i + 1]->next = my_node[i + 2];

	my_node[my_count]->next = NULL;
	my_node[0] = my_node[1];

	while (my_node[0] != NULL) {
		my_node[0] = my_node[0]->next;
	}

	delete[] timebuf;
	delete[] filebuf;
	delete[] my_node;
}

void Printer::show_log() {
	FILE* file;

	fopen_s(&file, "info.txt", "r");

	char* read_buf = new char[1024]{};
	char* temp_buf = new char[1024]{};

	if (file != nullptr)
		while (fgets(read_buf, 1024, file))
			strcat_s(temp_buf, 1024, read_buf);

	std::cout << temp_buf;

	if (file != nullptr)
		fclose(file);

	delete[] read_buf;
	delete[] temp_buf;
}