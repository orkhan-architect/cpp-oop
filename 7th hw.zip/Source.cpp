#include <iostream>
#include "np3.h"

int main()
{
	unsigned short operation = 0;
	bool checking = true;

	Printer xerox;

	xerox.users_count();
	xerox.client_and_priority();

	while (checking) {
		std::cout
			<< "Enter the operation number that you want proceed: " << '\n'
			<< "1. Reset printer" << '\n'
			<< "2. Change the cartridge" << '\n'
			<< "3. Fill the tray" << '\n'
			<< "4. Change the name of the client" << '\n'
			<< "5. Change the priority of the client" << '\n'
			<< "6. Show current users and priorities" << '\n'
			<< "7. Print session" << '\n'
			<< "8. Show Print LOG" << '\n'
			<< "9. EXIT" << '\n';

		std::cin >> operation;
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (operation)
		{
		case 1:
			xerox.users_count();
			xerox.client_and_priority();
			break;
		case 2:
			xerox.change_cartridge();
			break;
		case 3:
			xerox.fill_tray();
			break;
		case 4:
			xerox.change_user();
			break;
		case 5:
			xerox.change_priority();
			break;
		case 6:
			xerox.print_user();
			break;
		case 7:
			xerox.in_sesion();
			break;
		case 8:
			xerox.show_log();
			break;
		case 9:
			checking = false;
			break;
		default:
			std::cout << "You are out of range. Try again.";
			break;
		}
	}

	return 0;
}