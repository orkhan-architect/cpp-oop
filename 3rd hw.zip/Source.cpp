#include <iostream>
#include "oop2.h"

int main()
{
	unsigned short humans_count = 2;
	Human* persons = new Human[humans_count]{};

	for (size_t i = 0; i < humans_count; i++)
		persons[i].human_add();

	/* ----------------for persons print
	persons->human_print(humans_count, persons);
	*/

	unsigned short flats_count = 2;
	Flat flats;

	flats.flat_init(flats_count, persons);

	/* ----------------for flats print
	flats.flat_print(flats_count, humans_count, persons);
	*/

	unsigned short building_num = 112;
	House building;

	building.house_init(building_num, &flats);

	building.house_print(humans_count, flats_count, persons);

	delete[] persons;

	return 0;
}