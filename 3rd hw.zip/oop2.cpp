#include <iostream>
#include "oop2.h"

Human::Human() {
	name = new char[20]{};
	surname = new char[20]{};
	patronymic = new char[20]{};
	gender = new char[7]{};
	age = 0;
}

void Human::human_add() {
	std::cout << "+++++++++++++++++++++++++++++" << '\n';
	std::cout << "Enter the name of the person: ";
	gets_s(name, 20);
	std::cout << "Enter the surname of the person: ";
	gets_s(surname, 20);
	std::cout << "Enter the patronymic of the person: ";
	gets_s(patronymic, 20);
	std::cout << "Enter the gender of the person: ";
	gets_s(gender, 7);
	std::cout << "Enter the age of the person: ";
	std::cin >> age;

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
}

void Human::human_print(unsigned short pers_count, Human* pers) {
	std::cout << "------------------------------------------" << '\n';
	for (size_t i = 0; i < pers_count; i++)
		std::cout
		<< i + 1 << ". " << pers[i].surname << ' ' << pers[i].name << ' ' << pers[i].patronymic
		<< ", gender-" << pers[i].gender << ", age-" << pers[i].age << '\n';
}

Flat::Flat() {
	fl_number = nullptr;
	FlatHuman = nullptr;
}

void Flat::flat_init(unsigned short flats_count, Human* flhuman) {
	fl_number = new unsigned short[flats_count] {};
	for (size_t i = 0; i < flats_count; i++) {
		std::cout << "+++++++++++++++++++++++++++" << '\n';
		std::cout << "Enter the number of the flat: ";
		std::cin >> fl_number[i];

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');
	}

	this->FlatHuman = flhuman;
}

void Flat::flat_print(unsigned short pers_count, unsigned short flats_count, Human* flhuman) {	
	std::cout << "------------------------------------------" << '\n' << "The number of the flat is: ";
	for (size_t i = 0; i < flats_count; i++) {
		std::cout << Flat::fl_number[i];
		if (i != flats_count - 1)
			std::cout << ", ";
		else
			std::cout << ".";
	}
	std::cout << '\n';
	FlatHuman->human_print(pers_count, flhuman);
}

House::House() {
	ho_number = 0;
	HouseFlat = nullptr;
}

void House::house_init(unsigned short ho_num, Flat* hoflat) {
	this->ho_number = ho_num;
	this->HouseFlat = hoflat;
}

void House::house_print(unsigned short pers_count, unsigned short flats_count, Human* flhuman)
{
	std::cout << "------------------------------------------" << '\n' << "House number is: " << ho_number << '\n';
	HouseFlat->flat_print(pers_count, flats_count, flhuman);
}