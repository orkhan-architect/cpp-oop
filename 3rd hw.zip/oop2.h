#pragma once

class Human {
private:
	char* name;
	char* surname;
	char* patronymic;
	char* gender;
	unsigned short age;

public:
#pragma region Getters
	char* GetName() const { return name; }
	char* GetSurname() const { return surname; }
	char* GetPatronymic() const { return patronymic; }
	char* GetGender() const { return gender; }
	unsigned short GetAge() const { return age; }
#pragma endregion
	
	Human();
	void human_add();
	void human_print(unsigned short pers_count, Human* pers);
};

class Flat {
private:
	unsigned short* fl_number;
	Human* FlatHuman;

public:
#pragma region 
	unsigned short* GetFlNumber() const { return fl_number; }
	Human* GetflHuman() const { return FlatHuman; }
#pragma endregion

	Flat();
	void flat_init(unsigned short flats_count, Human* flhuman);
	void flat_print(unsigned short pers_count, unsigned short flats_count, Human* flhuman);
};

class House {
private:
	unsigned short ho_number;
	Flat* HouseFlat;

public:
#pragma region 
	unsigned short GetHoNumber() const { return ho_number; }
	Flat* GetHoFlat() const { return HouseFlat; }
#pragma endregion

	House();
	void house_init(unsigned short ho_num, Flat* hoflat);
	void house_print(unsigned short pers_count, unsigned short flats_count, Human* flhuman);
};