#pragma once
#include <cstdio>

class String {
private:
	char* something;

public:
#pragma region Getters
	char* GetSome() const 
	{
		return something;
	}
#pragma endregion
	String() {
		something = new char[1024]{};
		std::cout << "Enter some text here less than 80 symbols: " << std::endl;
		gets_s(something, 1024);

		if (strlen(something) > 80) {
			delete[] something;
			String();
		}
	}

	String(unsigned short length) {
		something = new char[1024]{};
		std::cout << "Enter some text here less than " << length <<" symbols: " << std::endl;
		gets_s(something, 1024);

		if (strlen(something) > length) {
			delete[] something;
			String String(length);
		}
	}
};