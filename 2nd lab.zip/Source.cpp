#include <iostream>
#include "oop1.h"

int main()
{
	// 1st constructor
	String anything;
	std::cout << "------------------- \n" << anything.GetSome() << std::endl;

	// 2nd constructor
	unsigned short a = 0;
	std::cout << "Enter the length for the string: ";
	std::cin >> a;

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	String anything2(a);
	std::cout << "----------------- \n" << anything2.GetSome() << std::endl;

	return 0;
}