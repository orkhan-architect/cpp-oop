#pragma once
#include <iostream>
#include <string>

class Mother_Exception {
protected:
	std::string message;
	unsigned short err_code;

public:
	Mother_Exception() {
		message = "Unknown error";
		err_code = 0;
	}

	Mother_Exception(std::string message, unsigned short err_code) {
		this->message = message;
		this->err_code = err_code;
	}

	virtual void show_error() = 0;
};

class Person {
private:
	std::string NSP;
	std::string gender;
	unsigned short age;

public:
	Person() {
		NSP = "none";
		gender = "none";
		age = 0;
	}

	Person(std::string p_NSP, std::string p_gender, unsigned short p_age)
		: NSP(p_NSP), gender(p_gender), age(p_age) {
	}

	std::string Get_pers_name() const { return NSP; }

	void show_person() const {
		std::cout
			<< "Surname Name Patronymic ->" << '\t' << NSP << '\n'
			<< "Gender ->" << "\t\t\t" << gender << '\n'
			<< "Age ->" << "\t\t\t\t" << age << '\n';
	}
};