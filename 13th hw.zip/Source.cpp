#include <iostream>
#include "common.h"
#include "teacher.h"
#include "cathedra.h"
#include "student.h"
#include "university.h"

int main()
{
	Teacher teacher("Math", 700, Person("Aliyev Hafiz Nadir", "male", 35));

	teacher.edit_subject("Algebra");

	try {
		teacher.add_group(87);
		teacher.add_group(65);
		teacher.add_group(98);
		//teacher.add_group(65);
	}
	catch (Teac_Exception ex1) {
		ex1.show_error();
	}

	try {
		teacher.delete_group(65);
		//teacher.delete_group(102);
	}
	catch (Teac_Exception ex2) {
		ex2.show_error();
	}

	//teacher.show_teacher();

	Teacher teacher_1("Math", 500, Person("Aliyeva Samira Famil", "female", 27));
	try {
		teacher_1.add_group(87);
		teacher_1.add_group(65);
	}
	catch (Teac_Exception ex1) {
		ex1.show_error();
	}

	Cathedra cat_1("Chemistry");

	cat_1.edit_cathedra("Mathematics");

	try {
		cat_1.add_subject(new char[] { "Math" });
		cat_1.add_subject(new char[] { "Algebra" });
		cat_1.add_subject(new char[] { "Analitic math" });
		//cat_1.add_subject(new char[] { "Algebra" });
	}
	catch (Cath_Exception ex3) {
		ex3.show_error();
	}

	try {
		cat_1.delete_subject(new char[] { "Algebra" });
		//cat_1.delete_subject(new char[] { "Sport" });
	}
	catch (Cath_Exception ex4) {
		ex4.show_error();
	}

	cat_1.add_teacher(teacher);
	cat_1.add_teacher(teacher_1);

	//cat_1.show_cathedra();

	Student* students = new Student[2]{ (Person("Salayev Sanan Adil", "male", 21)), (Person("Huseynova Naila Samil", "female", 19)) };

	try {
		students[0].add_subject(new char[] {"Math"});
		students[0].add_subject(new char[] {"Analitic math"});
		//students[0].add_subject(new char[] {"Math"});
	}
	catch (Stud_Exception ex5) {
		ex5.show_error();
	}

	try {
		students[1].add_subject(new char[] {"Math"});
		students[1].add_subject(new char[] {"Analitic math"});
	}
	catch (Stud_Exception ex5) {
		ex5.show_error();
	}

	students[0].add_grade(11);
	students[0].add_grade(10);

	students[1].add_grade(10);
	students[1].add_grade(9);

	//students[0].show_student();
	//students[1].show_student();

	University university("Baku State University");

	try {
		university.add_cathedra(cat_1);
		//university.add_cathedra(cat_1);
	}
	catch (Uni_Exception ex6) {
		ex6.show_error();
	}

	try {
		university.add_teacher(teacher);
		university.add_teacher(teacher_1);
		//university.add_teacher(teacher);
	}
	catch (Uni_Exception ex7) {
		ex7.show_error();
	}

	try {
		university.add_student(students[0]);
		university.add_student(students[1]);
		//university.add_student(students[0]);
	}
	catch (Uni_Exception ex8) {
		ex8.show_error();
	}

	try {
		university.delete_teacher("Aliyev Hafiz Nadir");
		//university.delete_teacher("Aliyev Hafiz Nadir");
	}
	catch (Uni_Exception ex9) {
		ex9.show_error();
	}

	try {
		university.delete_student("Huseynova Naila Samil");
		//university.delete_student("Huseynova Naila Samil");
	}
	catch (Uni_Exception ex10) {
		ex10.show_error();
	}

	try {
		//university.delete_cathedra("Mathematics");
	}
	catch (Uni_Exception ex11) {
		ex11.show_error();
	}

	try {
		university.increase_salary("Aliyeva Samira Famil", 900);
		//university.increase_salary("Aliyev Samir Famil", 900);
		//university.increase_salary("Aliyeva Samira Famil", 900);
	}
	catch (Uni_Exception ex12) {
		ex12.show_error();
	}

	university.show_university();

	return 0;
}