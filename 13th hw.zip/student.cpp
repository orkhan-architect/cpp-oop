#include "student.h"
#include <cstring>

Student::Student() {
	subjects = nullptr;
	scholarship = 0;
	average_grade = 0;
	grades = nullptr;
	subjects_count = 0;
	grades_count = 0;
}

Student::Student(Person stu_name) {
	this->person = stu_name;
	subjects = nullptr;
	scholarship = 0;
	average_grade = 0;
	grades = nullptr;
	subjects_count = 0;
	grades_count = 0;
}

void Student::show_student() const {
	std::cout
		<< "Student's info ---------------------" << '\n'
		<< "Student's average grade ->" << '\t' << average_grade << '\n'
		<< "Student's scholarship ->" << '\t' << scholarship << " USD " << '\n';

	show_subject();
	show_grades();
	person.show_person();
}

void Student::add_subject(char* subject) {

	unsigned short copies_count = 0;
	for (size_t i = 0; i < subjects_count; i++)
		if (strcmp(subjects[i], subject) == 0)
			++copies_count;

	if (subjects_count == 0 || copies_count == 0) {

		char** tmp = nullptr;
		if (subjects_count > 0) {
			tmp = new char* [subjects_count];
			for (size_t i = 0; i < subjects_count; i++)
				tmp[i] = new char[30]{};

			for (size_t i = 0; i < subjects_count; i++)
				tmp[i] = subjects[i];
		}

		delete[] subjects;

		subjects_count++;
		subjects = new char* [subjects_count];
		for (size_t i = 0; i < subjects_count; i++)
			subjects[i] = new char[30]{};

		if (subjects_count > 1)
			for (size_t i = 0; i < subjects_count - 1; i++)
				subjects[i] = tmp[i];

		subjects[subjects_count - 1] = subject;

		delete[] tmp;
	}
	else {
		throw Stud_Exception("Trying create existing subject", 500);
	}
}

void Student::show_subject() const {
	std::cout << "Student's subjects ->" << "\t\t";
	for (size_t i = 0; i < subjects_count; i++)
		std::cout << subjects[i] << ". ";

	std::cout << std::endl;
}

void Student::add_grade(unsigned short grade) {

	unsigned short* tmp = nullptr;
	if (grades_count > 0) {
		tmp = new unsigned short[grades_count];

		for (size_t i = 0; i < grades_count; i++)
			tmp[i] = grades[i];
	}

	delete[] grades;

	grades_count++;
	grades = new unsigned short[grades_count];

	if (grades_count > 1)
		for (size_t i = 0; i < grades_count - 1; i++)
			grades[i] = tmp[i];

	grades[grades_count - 1] = grade;

	float grades_sum = 0;
	for (size_t i = 0; i < grades_count; i++)
		grades_sum += grades[i];

	average_grade = grades_sum / grades_count;

	if (average_grade > 8 && average_grade <= 10)
		scholarship = 50;
	else if (average_grade > 10 && average_grade <= 12)
		scholarship = 70;

	delete[] tmp;
}

void Student::show_grades() const {
	std::cout << "Grades for all subjects ->" << '\t';
	for (size_t i = 0; i < grades_count; i++)
		std::cout << grades[i] << ". ";

	std::cout << std::endl;
}