#include "university.h"
#include <cstring>

University::University() {
	name = "none";
	cathedras = nullptr;
	teachers = nullptr;
	students = nullptr;
	cathedras_count = 0;
	teachers_count = 0;
	students_count = 0;
}

University::University(std::string uni_name) {
	this->name = uni_name;
	cathedras = nullptr;
	teachers = nullptr;
	students = nullptr;
	cathedras_count = 0;
	teachers_count = 0;
	students_count = 0;
}

void University::add_cathedra(Cathedra cathr) {

	unsigned short copies_count = 0;
	for (size_t i = 0; i < cathedras_count; i++)
		if (cathedras[i].Get_cath_name().compare(cathr.Get_cath_name()) == 0)
			++copies_count;

	if (cathedras_count == 0 || copies_count == 0) {

		Cathedra* tmp = nullptr;
		if (cathedras_count > 0) {
			tmp = new Cathedra[cathedras_count];
			for (size_t i = 0; i < cathedras_count; i++)
				tmp[i] = cathedras[i];
		}
		delete[] cathedras;

		cathedras_count++;
		cathedras = new Cathedra[cathedras_count];
		if (cathedras_count > 1)
			for (size_t i = 0; i < cathedras_count - 1; i++)
				cathedras[i] = tmp[i];

		cathedras[cathedras_count - 1] = cathr;

		delete[] tmp;
	}
	else {
		throw Uni_Exception("Trying create existing cathedra", 100);
	}
}

void University::add_teacher(Teacher tchr) {
	unsigned short copies_count = 0;
	for (size_t i = 0; i < teachers_count; i++)
		if (teachers[i].Get_teac_name().compare(tchr.Get_teac_name()) == 0)
			++copies_count;

	if (teachers_count == 0 || copies_count == 0) {

		Teacher* tmp = nullptr;
		if (teachers_count > 0) {
			tmp = new Teacher[teachers_count];
			for (size_t i = 0; i < teachers_count; i++)
				tmp[i] = teachers[i];
		}
		delete[] teachers;

		teachers_count++;
		teachers = new Teacher[teachers_count];
		if (teachers_count > 1)
			for (size_t i = 0; i < teachers_count - 1; i++)
				teachers[i] = tmp[i];

		teachers[teachers_count - 1] = tchr;

		delete[] tmp;
	}
	else {
		throw Uni_Exception("Trying add existing teacher", 101);
	}
}

void University::add_student(Student stud) {
	unsigned short copies_count = 0;
	for (size_t i = 0; i < students_count; i++)
		if (students[i].Get_stud_name().compare(stud.Get_stud_name()) == 0)
			++copies_count;

	if (students_count == 0 || copies_count == 0) {

		Student* tmp = nullptr;
		if (students_count > 0) {
			tmp = new Student[students_count];
			for (size_t i = 0; i < students_count; i++)
				tmp[i] = students[i];
		}
		delete[] students;

		students_count++;
		students = new Student[students_count];
		if (students_count > 1)
			for (size_t i = 0; i < students_count - 1; i++)
				students[i] = tmp[i];

		students[students_count - 1] = stud;

		delete[] tmp;
	}
	else {
		throw Uni_Exception("Trying add existing student", 102);
	}
}

void University::show_university() const {
	std::cout << "Cathedras count -> " << cathedras_count << '\n';
	for (size_t i = 0; i < cathedras_count; i++) {
		cathedras[i].show_cathedra();
		std::cout << std::endl;
	}

	std::cout << "Teachers count -> " << teachers_count << '\n';
	for (size_t i = 0; i < teachers_count; i++) {
		teachers[i].show_teacher();
		std::cout << std::endl;
	}

	std::cout << std::endl;

	std::cout << "Students count -> " << students_count << '\n';
	for (size_t i = 0; i < students_count; i++) {
		students[i].show_student();
		std::cout << std::endl;
	}
}

void University::delete_teacher(std::string teac_name) {
	for (size_t i = 0; i < teachers_count; i++) {
		if (teachers[i].Get_teac_name().compare(teac_name) == 0) {

			Teacher* tmp = nullptr;
			tmp = new Teacher[teachers_count - 1];

			for (size_t j = 0, k = 0; j < teachers_count; j++) {
				if (teachers[j].Get_teac_name().compare(teac_name) == 0) {
					continue;
				}
				else {
					tmp[k] = teachers[j];
					k++;
				}
			}

			delete[] teachers;

			teachers_count--;
			teachers = new Teacher[teachers_count];

			for (size_t i = 0; i < teachers_count; i++)
				teachers[i] = tmp[i];

			break;
		}
		else if (i == teachers_count - 1 && teachers[i].Get_teac_name().compare(teac_name) != 0) {
			throw Uni_Exception("This teacher not found", 103);
		}
	}

	for (size_t b = 0; b < cathedras_count; b++) {
		for (size_t i = 0; i < cathedras[b].teachers_count; i++) {
			if (cathedras[b].teachers[i].Get_teac_name().compare(teac_name) == 0) {

				Teacher* tmp = nullptr;
				tmp = new Teacher[cathedras[b].teachers_count - 1];

				for (size_t j = 0, k = 0; j < cathedras[b].teachers_count; j++) {
					if (cathedras[b].teachers[j].Get_teac_name().compare(teac_name) == 0) {
						continue;
					}
					else {
						tmp[k] = cathedras[b].teachers[j];
						k++;
					}
				}

				delete[] cathedras[b].teachers;

				(cathedras[b].teachers_count)--;
				cathedras[b].teachers = new Teacher[cathedras[b].teachers_count];

				for (size_t m = 0; m < cathedras[b].teachers_count; m++)
					cathedras[b].teachers[m] = tmp[m];

				break;
			}
		}
	}
}

void University::delete_student(std::string stud_name) {
	for (size_t i = 0; i < students_count; i++) {
		if (students[i].Get_stud_name().compare(stud_name) == 0) {

			Student* tmp = nullptr;
			tmp = new Student[students_count - 1];

			for (size_t j = 0, k = 0; j < students_count; j++) {
				if (students[j].Get_stud_name().compare(stud_name) == 0) {
					continue;
				}
				else {
					tmp[k] = students[j];
					k++;
				}
			}

			delete[] students;

			students_count--;
			students = new Student[students_count];

			for (size_t i = 0; i < students_count; i++)
				students[i] = tmp[i];

			break;
		}
		else if (i == students_count - 1 && students[i].Get_stud_name().compare(stud_name) != 0) {
			throw Uni_Exception("This student not found", 104);
		}
	}
}

void University::delete_cathedra(std::string cath_name) {
	for (size_t i = 0; i < cathedras_count; i++) {
		if (cathedras[i].Get_cath_name().compare(cath_name) == 0) {

			Cathedra* tmp = nullptr;
			tmp = new Cathedra[cathedras_count - 1];

			for (size_t j = 0, k = 0; j < cathedras_count; j++) {
				if (cathedras[j].Get_cath_name().compare(cath_name) == 0) {
					continue;
				}
				else {
					tmp[k] = cathedras[j];
					k++;
				}
			}

			delete[] cathedras;

			cathedras_count--;
			cathedras = new Cathedra[cathedras_count];

			for (size_t i = 0; i < cathedras_count; i++)
				cathedras[i] = tmp[i];

			break;
		}
		else if (i == cathedras_count - 1 && cathedras[i].Get_cath_name().compare(cath_name) != 0) {
			throw Uni_Exception("This cathedra not found", 105);
		}
	}
}

void University::increase_salary(std::string teac_name, unsigned short new_salary) {
	for (size_t i = 0; i < teachers_count; i++) {
		if (teachers[i].Get_teac_name().compare(teac_name) == 0) {
			if (teachers[i].salary < new_salary)
				teachers[i].salary = new_salary;
			else
				throw Uni_Exception("You are not increasing salary", 107);

			break;
		}
		else if (i == teachers_count - 1 && teachers[i].Get_teac_name().compare(teac_name) != 0) {
			throw Uni_Exception("This teacher not found for salary bonus", 106);
		}
	}

	for (size_t b = 0; b < cathedras_count; b++) {
		for (size_t i = 0; i < cathedras[b].teachers_count; i++) {
			if (teachers[i].Get_teac_name().compare(teac_name) == 0) {
				if (cathedras[b].teachers[i].salary < new_salary)
					cathedras[b].teachers[i].salary = new_salary;

				break;
			}
		}
	}
}