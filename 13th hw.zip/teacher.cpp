#include "cathedra.h"
#include <cstring>

Teacher::Teacher() {
	subject = "none";
	groups_number = nullptr;
	salary = 0;
	groups_count = 0;
}

Teacher::Teacher(std::string te_subject, unsigned short te_salary, Person te_name) {
	this->subject = te_subject;
	this->salary = te_salary;
	this->person = te_name;
}

void Teacher::show_teacher() const {
	std::cout
		<< "Teacher's info ---------------------" << '\n'
		<< "Teacher's subject ->" << "\t\t" << subject << '\n'
		<< "Teacher's salary ->" << "\t\t" << salary << " USD " << '\n'
		<< "Teaching groups count ->" << '\t' << groups_count << '\n';

	person.show_person();
	show_group();
}

void Teacher::edit_subject(std::string new_name) {
	this->subject = new_name;
}

void Teacher::add_group(size_t number) {
	unsigned short copies_count = 0;
	for (size_t i = 0; i < groups_count; i++)
		if (groups_number[i] == number)
			++copies_count;

	if (groups_count == 0 || copies_count == 0) {

		size_t* tmp = nullptr;
		if (groups_count > 0) {
			tmp = new size_t [groups_count];

			for (size_t i = 0; i < groups_count; i++)
				tmp[i] = groups_number[i];
		}

		delete[] groups_number;

		groups_count++;
		groups_number = new size_t [groups_count];

		if (groups_count > 1)
			for (size_t i = 0; i < groups_count - 1; i++)
				groups_number[i] = tmp[i];

		groups_number[groups_count - 1] = number;

		delete[] tmp;
	}
	else {
		throw Teac_Exception("Trying create existing group number", 300);
	}
}

void Teacher::show_group() const {
	std::cout << "Is teaching these groups ->" << '\t';
	for (size_t i = 0; i < groups_count; i++)
		std::cout << groups_number[i] << ". ";
}

void Teacher::delete_group(size_t number) {
	for (size_t i = 0; i < groups_count; i++) {
		if (groups_number[i] == number) {

			size_t* tmp = nullptr;
			tmp = new size_t [groups_count - 1];

			for (size_t j = 0, k = 0; j < groups_count; j++) {
				if (groups_number[j] == number) {
					continue;
				}
				else {
					tmp[k] = groups_number[j];
					k++;
				}
			}

			delete[] groups_number;

			groups_count--;
			groups_number = new size_t [groups_count];

			for (size_t i = 0; i < groups_count; i++)
				groups_number[i] = tmp[i];

			break;
		}
		else if (i == groups_count - 1 && groups_number[i] != number) {
			throw Teac_Exception("Group not found", 301);
		}
	}
}