#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include "common.h"

class Teac_Exception : public Mother_Exception
{
private:
	FILE* file;
	std::string log;

public:
	Teac_Exception() : Mother_Exception() {
		file = nullptr;
		log = " ";
	}

	Teac_Exception(std::string message, unsigned short err_code) : Mother_Exception(message, err_code) {

		struct tm newtime;
		__time64_t long_time;
		char* timebuf = new char[26]{};
		_time64(&long_time);
		_localtime64_s(&newtime, &long_time);
		asctime_s(timebuf, 26, &newtime);

		log = message + ' ' + std::to_string(err_code) + '\n' + "---------------------" + '\n';

		fopen_s(&file, "teac_exc.txt", "a");

		if (file) {
			fputs(timebuf, file);
			fputs(log.c_str(), file);
		}

		if (file)
			fclose(file);
	}

	void show_error() override {
		std::cout << log;
	}
};

class Teacher {
private:
	Person person;
	std::string subject;
	size_t* groups_number;
	unsigned short groups_count;

public:
	unsigned short salary;

	Teacher();
	Teacher(std::string, unsigned short, Person);

#pragma region methods
	std::string Get_teac_name() const { return person.Get_pers_name(); }
	void show_teacher() const;
	void edit_subject(std::string);
	void add_group(size_t);
	void show_group() const;
	void delete_group(size_t);
#pragma endregion
};