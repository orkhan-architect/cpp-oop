#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include "common.h"
#include "cathedra.h"
#include "student.h"
#include "teacher.h"

class Uni_Exception : public Mother_Exception
{
private:
	FILE* file;
	std::string log;

public:
	Uni_Exception() : Mother_Exception() {
		file = nullptr;
		log = " ";
	}
	Uni_Exception(std::string message, unsigned short err_code) : Mother_Exception(message, err_code) {

		struct tm newtime;
		__time64_t long_time;
		char* timebuf = new char[26]{};
		_time64(&long_time);
		_localtime64_s(&newtime, &long_time);
		asctime_s(timebuf, 26, &newtime);

		log = message + ' ' + std::to_string(err_code) + '\n' + "---------------------" + '\n';

		fopen_s(&file, "uni_exc.txt", "a");

		if (file) {
			fputs(timebuf, file);
			fputs(log.c_str(), file);
		}

		if (file)
			fclose(file);
	}

	void show_error() override {
		std::cout << log;
	}
};

class University {
private:
	std::string name;
	Cathedra* cathedras;
	Teacher* teachers;
	Student* students;
	size_t cathedras_count;
	size_t teachers_count;
	size_t students_count;

public:
	University();
	University(std::string);

#pragma region methods
	void add_cathedra(Cathedra);
	void add_teacher(Teacher);
	void add_student(Student);
	void show_university() const;
	void delete_teacher(std::string);
	void delete_student(std::string);
	void delete_cathedra(std::string);
	void increase_salary(std::string, unsigned short);
#pragma endregion
};