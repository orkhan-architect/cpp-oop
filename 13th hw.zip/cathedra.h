#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include "common.h"
#include "teacher.h"

class Cath_Exception : public Mother_Exception
{
private:
	FILE* file;
	std::string log;

public:
	Cath_Exception() : Mother_Exception() {
		file = nullptr;
		log = " ";
	}
	Cath_Exception(std::string message, unsigned short err_code) : Mother_Exception(message, err_code) {

		struct tm newtime;
		__time64_t long_time;
		char* timebuf = new char[26]{};
		_time64(&long_time);
		_localtime64_s(&newtime, &long_time);
		asctime_s(timebuf, 26, &newtime);

		log = message + ' ' + std::to_string(err_code) + '\n' + "---------------------" + '\n';

		fopen_s(&file, "cath_exc.txt", "a");

		if (file) {
			fputs(timebuf, file);
			fputs(log.c_str(), file);
		}

		if (file)
			fclose(file);
	}

	void show_error() override {
		std::cout << log;
	}
};

class Cathedra {
private:	
	std::string name;
	char** subjects;
	size_t subjects_count;

public:
	Teacher* teachers;
	size_t teachers_count;

	Cathedra();
	Cathedra(std::string);

#pragma region methods
	std::string Get_cath_name() const { return name; }
	void add_teacher(Teacher);
	void add_subject(char*);
	void delete_subject(char*);
	void edit_cathedra(std::string);
	void show_cathedra() const;
	void show_subjects() const;
#pragma endregion
};