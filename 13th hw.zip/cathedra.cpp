#include "cathedra.h"
#include <cstring>

Cathedra::Cathedra() {
	name = "none";
	subjects = nullptr;
	teachers = nullptr;
	teachers_count = 0;
	subjects_count = 0;
}

Cathedra::Cathedra(std::string c_name) {
	this->name = c_name;
}

void Cathedra::add_teacher(Teacher tchr) {
	Teacher* tmp = nullptr;
	if (teachers_count > 0) {
		tmp = new Teacher [teachers_count];
		for (size_t i = 0; i < teachers_count; i++)
			tmp[i] = teachers[i];
	}
	delete[] teachers;

	teachers_count++;
	teachers = new Teacher[teachers_count];
	if (teachers_count > 1)
		for (size_t i = 0; i < teachers_count-1; i++)
			teachers[i] = tmp[i];

	teachers[teachers_count - 1] = tchr;

	delete[] tmp;
}

void Cathedra::add_subject(char* subject) {

	unsigned short copies_count = 0;
	for (size_t i = 0; i < subjects_count; i++)
		if (strcmp(subjects[i], subject) == 0)
			++copies_count;

	if(subjects_count == 0 || copies_count == 0) {

		char** tmp = nullptr;
		if (subjects_count > 0) {
			tmp = new char* [subjects_count];
			for (size_t i = 0; i < subjects_count; i++)
				tmp[i] = new char[30]{};

			for (size_t i = 0; i < subjects_count; i++)
				tmp[i] = subjects[i];
		}

		delete[] subjects;

		subjects_count++;
		subjects = new char* [subjects_count];
		for (size_t i = 0; i < subjects_count; i++)
			subjects[i] = new char[30]{};

		if (subjects_count > 1)
			for (size_t i = 0; i < subjects_count - 1; i++)
				subjects[i] = tmp[i];

		subjects[subjects_count - 1] = subject;

		delete[] tmp;
	}
	else {
		throw Cath_Exception("Trying create existing subject", 200);
	}
}

void Cathedra::delete_subject(char* subject) {
	for (size_t i = 0; i < subjects_count; i++) {
		if (strcmp(subjects[i], subject) == 0) {

			char** tmp = nullptr;
			tmp = new char* [subjects_count - 1];
			for (size_t i = 0; i < subjects_count - 1; i++)
				tmp[i] = new char[30]{};

			for (size_t j = 0, k = 0; j < subjects_count; j++) {
				if (strcmp(subjects[j], subject) == 0) {
					continue;
				}
				else {
					tmp[k] = subjects[j];
					k++;
				}
			}

			delete[] subjects;

			subjects_count--;
			subjects = new char* [subjects_count];
			for (size_t i = 0; i < subjects_count; i++)
				subjects[i] = new char[30]{};

			for (size_t i = 0; i < subjects_count; i++)
				subjects[i] = tmp[i];

			break;
		}
		else if (i == subjects_count - 1 && strcmp(subjects[i], subject) != 0) {
			throw Cath_Exception("Subject not found", 201);
		}
	}
}

void Cathedra::edit_cathedra(std::string new_name) {
	this->name = new_name;
}

void Cathedra::show_subjects() const{
	std::cout << "Existing subjects ->" << "\t\t";
	for (size_t i = 0; i < subjects_count; i++)
		std::cout << subjects[i] << ". ";
}

void Cathedra::show_cathedra() const {
	std::cout
		<< "Cathedra info ---------------------" << '\n'
		<< "Cathedra name ->" << "\t\t" << name << '\n'
		<< "Teachers count ->" << "\t\t" << teachers_count << '\n'
		<< "Subjects count ->" << "\t\t" << subjects_count << '\n';

	show_subjects();
	std::cout << std::endl;

	for (size_t i = 0; i < teachers_count; i++)	{
		teachers[i].show_teacher();
		std::cout << std::endl;
	}
}