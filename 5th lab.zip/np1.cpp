#include <iostream>
#include "np1.h"

Date::Date() {
	day = 0;
	month = 0;
	year = 0;
}

void Date::add_date() {
	std::cout << "Enter the random year: ";
	std::cin >> year;
	while (year < 1900 || year > 3000) {
		std::cout << "Try again, you must enter the year equal or bigger than 1900: ";
		std::cin >> year;
	}

	std::cout << "Enter the month number of the year: ";
	std::cin >> month;
	while (month <= 0 || month > 12) {
		std::cout << "Try again, you must enter the month between 1-12: ";
		std::cin >> month;
	}

	std::cout << "Enter the day of the month: ";
	std::cin >> day;
	if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
		while (day <= 0 || day > 31) {
			std::cout << "Try again, enter the correct day of the month: ";
			std::cin >> day;
		}
	}
	else if (month == 4 || month == 6 || month == 9 || month == 11) {
		while (day <= 0 || day > 30) {
			std::cout << "Try again, enter the correct day of the month: ";
			std::cin >> day;
		}
	}
	else {
		if ((year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)) {
			while (day <= 0 || day > 29) {
				std::cout << "Try again, enter the correct day of the month: ";
				std::cin >> day;
			}
		}
		else {
			while (day <= 0 || day > 28) {
				std::cout << "Try again, enter the correct day of the month: ";
				std::cin >> day;
			}
		}
	}

	std::cout << std::endl;
}

void Date::print() {
	std::cout << "Your created date is: " << Get_Day() << '-' << Get_Month() << '-' << Get_Year() << '\n';
	std::cout << "----------------------------" << '\n';
	std::cout << std::endl;
}

int Date::date_converter(unsigned short day, unsigned short month, unsigned short year) {
	unsigned short ly_count = 0, created_year = year;
	int days_count = 0;

	year--;

	for (size_t i = 1; i < year; i++)
		if ((i % 4 == 0) && (i % 100 != 0 || i % 400 == 0))
			ly_count++;

	days_count = ly_count * 366 + (year - ly_count) * 365;

	unsigned short* sy_month = new unsigned short[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
	unsigned short* ly_month = new unsigned short[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };

	for (size_t i = 0; i < 12; i++) {
		if ((month - 1) == i) {
			if ((created_year % 4 == 0) && (created_year % 100 != 0 || created_year % 400 == 0)) {
				days_count += ly_month[i];
			}
			else {
				days_count += sy_month[i];
			}
			break;
		}
	}

	days_count += day;

	year++;

	return days_count;
}

void Date::days_converter(unsigned int days) {
	unsigned short get_day=0, get_month=0, get_year=0;
	unsigned short* month_days = nullptr;
	unsigned short* end_days = nullptr;
	unsigned int temp_days = days;

	unsigned short quadro_years = 4 * 365 + 1;

	unsigned int first_floor = temp_days / quadro_years;
	get_year = first_floor * 4;

	temp_days -= first_floor * quadro_years;

	if (temp_days != 0) {
		for (size_t i = 0; i < 3; i++) {
			if (temp_days > 365) {
				temp_days -= 365;
				get_year += 1;
			}
			else {
				break;
			}
		}

		if (((get_year + 1) % 4 == 0) && ((get_year + 1) % 100 != 0 || (get_year + 1) % 400 == 0))
			month_days = new unsigned short[] { 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 };
		else
			month_days = new unsigned short[] { 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };

		for (size_t i = 0; i < 12; i++) {
			if (temp_days <= month_days[i]) {
				get_month = i;
				if (get_month > 0)
					get_day = temp_days - month_days[i-1];
				else
					get_day = temp_days;
				break;
			}
		}		
	}
	std::cout << "--------------------------------" << '\n';
	std::cout << "Your entered " << days << " days as a date: " << get_day << '-' << get_month << '-' << get_year << '\n';

	unsigned short last_res_year, last_res_month, last_res_day;

	last_res_year = this->year + get_year;

	last_res_month = this->month + get_month;
	if (last_res_month > 12) {
		last_res_month -= 12;
		last_res_year++;
	}

	last_res_day = this->day + get_day;

	if ((last_res_year % 4 == 0) && (last_res_year % 100 != 0 || last_res_year % 400 == 0))
		end_days = new unsigned short[] { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	else
		end_days = new unsigned short[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	for (size_t i = 0; i < 12; i++)	{
		if (i == last_res_month - 1) {
			for (size_t k = 0; k < 2; k++) {
				if (i + k == 12)
					end_days[i + k] = end_days[0];
				if (last_res_day > end_days[i + k]) {
					last_res_day -= end_days[i + k];
					last_res_month++;
					if (last_res_month > 12) {
						last_res_month -= 12;
						last_res_year++;
					}
				}
			}
			break;
		}
	}

	std::cout << "After " << days << " days new date will be: " << last_res_day << '-' << last_res_month << '-' << last_res_year << '\n';
	std::cout << "--------------------------------" << '\n';
}