#pragma once

class Date {
private:
	unsigned short day;
	unsigned short month;
	unsigned short year;

public:
#pragma region Getters
	unsigned short Get_Day() const { return day; }
	unsigned short Get_Month() const { return month; }
	unsigned short Get_Year() const { return year; }
#pragma endregion

	Date();

	void add_date();
	void print();
	int date_converter(unsigned short day, unsigned short month, unsigned short year);
	void days_converter(unsigned int days);

#pragma region Operators
	void operator - (const Date& second_date) {
		int first_couple = date_converter(this->day, this->month, this->year);
		int second_couple = date_converter(second_date.day, second_date.month, second_date.year);

		int result = first_couple - second_couple;
		if (result < 0)
			result *= -1;

		std::cout << "You got " << result << " day(s) between these dates" << '\n';
		std::cout << std::endl;
	}

	void operator + (const unsigned int& days_count) {
		days_converter(days_count);
	}
#pragma endregion
};