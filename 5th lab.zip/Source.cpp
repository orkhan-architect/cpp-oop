#include <iostream>
#include "np1.h"

int main()
{
	unsigned short operation;
	bool checking = true;

	while (checking) {
		std::cout
			<< "Enter the operation number that you want proceed" << '\n'
			<< "1. Date subtraction" << '\n'
			<< "2. Date addition" << '\n'
			<< "3. EXIT" << '\n';
		std::cin >> operation;

		Date date_1;
		Date date_2;
		unsigned int any_number;
		
		if (operation == 1) {
			std::cout << "Enter first couple of the date:" << '\n';
			date_1.add_date();

			std::cout << "First couple of the date:" << '\n';
			date_1.print();

			std::cout << "Enter second couple of the date:" << '\n';
			date_2.add_date();

			std::cout << "Second couple of the date:" << '\n';
			date_2.print();
		}
		else if (operation == 2) {
			std::cout << "Enter the date:" << '\n';
			date_1.add_date();

			std::cout << "Entered date:" << '\n';
			date_1.print();

			std::cout << "Enter the days count which you will add your first couple: ";
			std::cin >> any_number;
			std::cout << std::endl;
		}

		switch (operation)
		{
		case 1:
			date_1 - date_2;
			break;
		case 2:
			date_1 + any_number;
			break;
		case 3:
			checking = false;
			break;
		default:
			std::cout << "You are out of the range. Try again." << std::endl;
			break;
		}
	}

	return 0;
}