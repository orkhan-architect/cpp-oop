#include <iostream>

template <typename T>
class List
{
private:
	struct Node
	{
		T data;
		Node* next;

		Node(T _data) { data = _data; }
		Node() { next = nullptr; }
	};

public:
	size_t size;
	unsigned int manual_stack;
	Node* head;

	List();
	~List();

	void add(T _data);
	void remove();
	void show() const;
};

template <typename T>
List<T>::List()
{
	size = 0;
	manual_stack = 1048576; // 1 MB = 1048576 bytes
	head = nullptr;
}

template <typename T>
List<T>::~List()
{
	for (int i = 0; i < size; ++i)
		remove();
}

template <typename T>
void List<T>::add(T _data)
{
	if (Node* node = new Node(_data)) {
		if (manual_stack > _data)
			manual_stack -= sizeof(_data);
		else
			manual_stack = 1048576;

		node->next = head;
		head = node;
		++size;
	}
}

template <typename T>
void List<T>::remove()
{
	if (head != nullptr) {
		Node* tmp = head->next;
		delete head;
		head = tmp;
		--size;
	}
}

template <typename T>
void List<T>::show() const
{
	Node* current = head;

	while (current != nullptr) {
		std::cout << current->data << ' ';
		current = current->next;
	}
}

int main()
{
	List<int> my_list;
	
	my_list.add(1);
	my_list.add(2);
	my_list.add(3);

	my_list.show();
	std::cout << std::endl;

	std::cout << my_list.manual_stack; // for checking manual stack progress

	return 0;
}