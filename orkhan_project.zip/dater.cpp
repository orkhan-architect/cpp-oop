#include "dater.h"

Date::Date() {
	day = 0;
	month = 0;
	year = 0;
}

void Date::add_date() {
	std::cout << "Enter the random year: ";
	std::cin >> year;
	while (year < 1900 || year > 3000) {
		std::cout << "Try again, you must enter the year equal or bigger than 1900: ";
		std::cin >> year;
	}

	std::cout << "Enter the month number of the year: ";
	std::cin >> month;
	while (month <= 0 || month > 12) {
		std::cout << "Try again, you must enter the month between 1-12: ";
		std::cin >> month;
	}

	std::cout << "Enter the day of the month: ";
	std::cin >> day;
	if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
		while (day <= 0 || day > 31) {
			std::cout << "Try again, enter the correct day of the month: ";
			std::cin >> day;
		}
	}
	else if (month == 4 || month == 6 || month == 9 || month == 11) {
		while (day <= 0 || day > 30) {
			std::cout << "Try again, enter the correct day of the month: ";
			std::cin >> day;
		}
	}
	else {
		if ((year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)) {
			while (day <= 0 || day > 29) {
				std::cout << "Try again, enter the correct day of the month: ";
				std::cin >> day;
			}
		}
		else {
			while (day <= 0 || day > 28) {
				std::cout << "Try again, enter the correct day of the month: ";
				std::cin >> day;
			}
		}
	}

	std::cout << std::endl;
}

int Date::date_converter(unsigned short day, unsigned short month, unsigned short year) {
	unsigned short ly_count = 0, created_year = year;
	int days_count = 0;

	year--;

	for (size_t i = 1; i < year; i++)
		if ((i % 4 == 0) && (i % 100 != 0 || i % 400 == 0))
			ly_count++;

	days_count = ly_count * 366 + (year - ly_count) * 365;

	unsigned short* sy_month = new unsigned short[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
	unsigned short* ly_month = new unsigned short[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };

	for (size_t i = 0; i < 12; i++) {
		if ((month - 1) == i) {
			if ((created_year % 4 == 0) && (created_year % 100 != 0 || created_year % 400 == 0)) {
				days_count += ly_month[i];
			}
			else {
				days_count += sy_month[i];
			}
			break;
		}
	}

	days_count += day;

	year++;

	return days_count;
}