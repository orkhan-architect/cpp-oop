#include <iostream>
#include "common.h"

int main()
{
	unsigned short log_oper = 0;
	bool log_checking = true;

	Users user;

	while (log_checking) {
		std::cout 
			<< "Enter the operation number that you want proceed" << '\n'
			<< "1. Login" << '\n'
			<< "2. Registration" << '\n'
			<< "3. Pass recovery" << '\n'
			<< "4. EXIT" << '\n';

		std::cin >> log_oper;
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (log_oper) {
		case 1:
			user.login_operation();
			break;
		case 2:
			user.registration();
			break;
		case 3:
			user.pass_recovery();
			break;
		case 4:
			log_checking = false;
			break;
		default:
			std::cout << "You are out of the range. Try again." << "\n\n";
			break;
		}
	}

	return 0;
}