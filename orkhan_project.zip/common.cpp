#include "common.h"

Users::Users() {
	NSP = "none";
	login = "none";
	password = "none";
	slogan = "none";
	in_session = false;
}

void Users::fst_out() {
	std::ofstream out;
	std::string user_path = login + "/user.txt";
	out.open(user_path);

	if (out.is_open()) {
		out
			<< NSP << '\n'
			<< login << '\n'
			<< password << '\n'
			<< slogan << '\n';
	}

	out.close();
}

void Users::fst_in(std::string temp_login) {

	std::string text_buffer;

	std::ifstream in;
	std::string user_path_rec = temp_login + "/user.txt";
	in.open(user_path_rec);

	if (in.is_open()) {
		unsigned short step = 0;
		while (getline(in, text_buffer)) {
			if (step == 0)
				NSP = text_buffer;
			else if (step == 1)
				login = text_buffer;
			else if (step == 2)
				password = text_buffer;
			else if (step == 3)
				slogan = text_buffer;

			step++;
		}
	}

	in.close();
}

void Users::registration() {
	std::cout << "Enter your name surname patronymic -> ";
	getline(std::cin, NSP);
	std::transform(NSP.begin(), NSP.end(), NSP.begin(), ::toupper);

	std::cout << "Enter your login name (FIN code of passport) -> ";
	getline(std::cin, login);
	std::transform(login.begin(), login.end(), login.begin(), ::toupper);

	std::cout << "Enter your secret word for password recovery -> ";
	getline(std::cin, slogan);
	std::transform(slogan.begin(), slogan.end(), slogan.begin(), ::toupper);
	SHA256 slog_hash;
	slogan = slog_hash(slogan);

	std::cout << "Enter your password -> ";
	getline(std::cin, password);
	SHA256 pass_hash;
	password = pass_hash(password);

	struct stat buffer;
	if (stat(login.c_str(), &buffer) != 0) {

		const char* user_directory = login.c_str();

		if (_mkdir(user_directory) == 0)
			std::cout << "Directory was created successfully" << '\n';

		fst_out();

		std::cout << "Account has been created. Go and login" << "\n\n";
	}
	else {
		std::cout << "This login name exists in our system" << "\n\n";
	}
}

void Users::edit_NSP() {
	std::cout << "Edit your name surname patronymic -> ";
	getline(std::cin, NSP);
	std::transform(NSP.begin(), NSP.end(), NSP.begin(), ::toupper);

	fst_out();

	std::cout << "Name surname patronymic has been edited." << "\n\n";
}

void Users::edit_slogan() {
	std::cout << "Edit your secret word for password recovery -> ";
	getline(std::cin, slogan);
	std::transform(slogan.begin(), slogan.end(), slogan.begin(), ::toupper);
	SHA256 slog_hash;
	slogan = slog_hash(slogan);

	fst_out();

	std::cout << "Slogan has been edited." << "\n\n";
}

void Users::edit_password() {
	std::cout << "Edit your password -> ";
	getline(std::cin, password);
	SHA256 pass_hash;
	password = pass_hash(password);

	fst_out();

	in_session = false;

	std::cout << "Password has been edited. Go and login again" << "\n\n";
}

void Users::pass_recovery() {
	std::string tmp_login;
	std::cout << "Enter your login name (FIN code of passport) for recovery -> ";
	getline(std::cin, tmp_login);
	std::transform(tmp_login.begin(), tmp_login.end(), tmp_login.begin(), ::toupper);

	std::string tmp_slogan;
	std::cout << "Enter your secret word that you registered by before -> ";
	getline(std::cin, tmp_slogan);
	std::transform(tmp_slogan.begin(), tmp_slogan.end(), tmp_slogan.begin(), ::toupper);
	SHA256 slog_hash_rec;
	tmp_slogan = slog_hash_rec(tmp_slogan);

	struct stat buffer;

	if (stat(tmp_login.c_str(), &buffer) == 0) {

		fst_in(tmp_login);

		if (slogan.compare(tmp_slogan) == 0) {

			std::cout << "Enter your new password -> ";
			getline(std::cin, password);
			SHA256 pass_hash;
			password = pass_hash(password);

			fst_out();

			std::cout << "You have changed your password successfully. Go and login" << "\n\n";
		}
		else {
			std::cout << "Your secret word is false" << "\n\n";
		}
	}
	else {
		std::cout << "There is no such user that you want recover password" << "\n\n";
	}
}

void Users::login_operation() {
	std::string tmp_login;
	std::cout << "Enter your login name (FIN code of passport) -> ";
	getline(std::cin, tmp_login);
	std::transform(tmp_login.begin(), tmp_login.end(), tmp_login.begin(), ::toupper);

	std::string tmp_password;
	std::cout << "Enter your password -> ";
	getline(std::cin, tmp_password);
	SHA256 pass_hash_login;
	tmp_password = pass_hash_login(tmp_password);

	struct stat buffer;
	if (stat(tmp_login.c_str(), &buffer) == 0) {
		
		fst_in(tmp_login);

		if (password.compare(tmp_password) == 0) {
			in_session = true;
			std::cout << "Welcome Mr/Mrs " << NSP << "\n\n";
		}
		else {
			std::cout << "Your password is false" << "\n\n";
		}
	}
	else {
		std::cout << "There is no such user that you want login" << "\n\n";
	}

	user_budget.upload_income(login);

	bool menu_checking = true;

	while (menu_checking) {
		if (in_session) {
			unsigned short menu_oper = 0;
			std::cout
				<< "Enter the operation number that you want proceed" << '\n'
				<< "1. Edit your name surname patronymic" << '\n'
				<< "2. Edit your password" << '\n'
				<< "3. Edit your slogan" << '\n'
				<< "4. Increase your income" << '\n'
				<< "5. Make your expense" << '\n'
				<< "6. Daily, weekly, monthly report" << '\n'
				<< "7. Weekly, monthly rating" << '\n'
				<< "8. LOGOUT" << '\n';

			std::cin >> menu_oper;
			std::cin.clear();
			std::cin.ignore(INT_MAX, '\n');

			switch (menu_oper) {
			case 1:
				edit_NSP();
				break;
			case 2:
				edit_password();
				break;
			case 3:
				edit_slogan();
				break;
			case 4:
				user_budget.increase_income(login);
				break;
			case 5:
				user_budget.expense_controlling(login);
				break;
			case 6:
				user_budget.report_print(login);
				break;
			case 7:
				user_budget.rating_print(login);
				break;
			case 8:
				menu_checking = false;
				break;
			default:
				std::cout << "You are out of the range. Try again." << "\n\n";
				break;
			}
		}
		else {
			menu_checking = false;
		}
	}
}