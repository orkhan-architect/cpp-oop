#pragma once
#include <iostream>

class Date {
private:
	unsigned short day;
	unsigned short month;
	unsigned short year;

public:
#pragma region Getters
	unsigned short Get_Day() const { return day; }
	unsigned short Get_Month() const { return month; }
	unsigned short Get_Year() const { return year; }
#pragma endregion

	Date();

	void add_date();
	int date_converter(unsigned short, unsigned short, unsigned short);
};