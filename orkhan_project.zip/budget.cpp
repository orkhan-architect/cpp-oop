#include "budget.h"

Budget::Budget() {
	this->income = new size_t[3]{ 0, 0, 0 };
	this->expense = { {"loans", 0}, {"monthly_demand", 0}, {"others", 0}, {"phone", 0}, {"transport", 0}, {"utilities", 0} };
}

int Budget::days_return(std::string str) {

	size_t first_found = str.find('-');
	size_t second_found = str.find('-', first_found + 1);

	std::string day_str = "", month_str = "", year_str = "";

	for (size_t i = 0; i < (int)str.size(); i++) {
		if (i < first_found) {
			day_str += str[i];
		}
		else if (i > first_found && i < second_found) {
			month_str += str[i];
		}
		else if (i > second_found) {
			year_str += str[i];
		}
	}

	unsigned short day = stoi(day_str);
	unsigned short month = stoi(month_str);
	unsigned short year = stoi(year_str);

	unsigned short ly_count = 0, created_year = year;
	int days_count = 0;

	year--;

	for (size_t i = 1; i < year; i++)
		if ((i % 4 == 0) && (i % 100 != 0 || i % 400 == 0))
			ly_count++;

	days_count = ly_count * 366 + (year - ly_count) * 365;

	unsigned short* sy_month = new unsigned short[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
	unsigned short* ly_month = new unsigned short[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };

	for (size_t i = 0; i < 12; i++) {
		if ((month - 1) == i) {
			if ((created_year % 4 == 0) && (created_year % 100 != 0 || created_year % 400 == 0)) {
				days_count += ly_month[i];
			}
			else {
				days_count += sy_month[i];
			}
			break;
		}
	}

	days_count += day;

	year++;

	return days_count;
}

void Budget::upload_income(std::string folder_path) {

	std::string income_file_path = folder_path + "/income.txt";

	struct stat income_buffer;

	if (stat(income_file_path.c_str(), &income_buffer) != 0) {

		std::ofstream out;
		out.open(income_file_path);

		if (out.is_open()) {
			out
				<< income[0] << '\n'
				<< income[1] << '\n'
				<< income[2] << '\n';
		}

		out.close();
	}
	else {

		std::string text_buffer;

		std::ifstream in;
		in.open(income_file_path);

		if (in.is_open()) {
			unsigned short step = 0;
			while (getline(in, text_buffer)) {
				if (step == 0)
					income[0] = stoi(text_buffer);
				else if (step == 1)
					income[1] = stoi(text_buffer);
				else if (step == 2)
					income[2] = stoi(text_buffer);

				step++;
			}
		}

		in.close();
	}
}

void Budget::increase_income(std::string folder_path) {

	unsigned short income_operation = 0;

	std::cout 
		<< "Enter the operation number that you want proceed" << '\n'
		<< "1. Increase cash" << '\n'
		<< "2. Increase debet card" << '\n'
		<< "3. Increase credit card" << '\n';

	std::cin >> income_operation;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

#pragma region income_increase_chrono
	int amount = 0;
	std::cout << "Enter income amount -> ";
	std::cin >> amount;
	while (amount < 0) {
		std::cout << "Try again. Enter income amount correctly -> ";
		std::cin >> amount;
	}

	Date date_in;

	date_in.add_date();

	std::ofstream out;
	std::string income_file_path = folder_path + "/income_crono.txt";
	out.open(income_file_path, std::ios::app);

	if (out.is_open()) {
		if (income_operation == 1) {
			income[0] += amount;
			out 
				<< date_in.Get_Day() << "-" << date_in.Get_Month() << "-" << date_in.Get_Year() << '\n'
				<< "Your cash is increased in " << amount << " USD" << '\n'
				<< "You have in cash " << income[0] << " USD" << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (income_operation == 2) {
			income[1] += amount;
			out
				<< date_in.Get_Day() << "-" << date_in.Get_Month() << "-" << date_in.Get_Year() << '\n'
				<< "Your debet card is increased in " << amount << " USD" << '\n'
				<< "You have in debet card " << income[1] << " USD" << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (income_operation == 3) {
			income[2] += amount;
			out
				<< date_in.Get_Day() << "-" << date_in.Get_Month() << "-" << date_in.Get_Year() << '\n'
				<< "Your credit card is increased in " << amount << " USD" << '\n'
				<< "You have in credit card " << income[2] << " USD" << '\n'
				<< "-----------------------------" << '\n';
		}
		else {
			std::cout << "Wrong choice" << "\n\n";
		}
	}

	out.close();
#pragma endregion

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

#pragma region Rewriting_INCOME_file
	std::ofstream out_income;
	income_file_path = folder_path + "/income.txt";
	out_income.open(income_file_path);

	if (out_income.is_open()) {
		out_income
			<< income[0] << '\n'
			<< income[1] << '\n'
			<< income[2] << '\n';
	}

	out_income.close();
#pragma endregion
}

void Budget::print_map_key() {
	std::map<std::string, size_t>::iterator itr;
	unsigned short step = 0;

	for (itr = expense.begin(); itr != expense.end(); ++itr, ++step) {
		std::cout << step+1 << ". Make payment - " << itr->first << '\n';
	}
}

void Budget::expense_controlling(std::string folder_path) {

#pragma region PayWith_choice
	std::cout 
		<< "Your budget for the current time" << '\n'
		<< "Enter the operation number that you will pay with" << '\n';

	for (size_t i = 0; i < 3; i++)
		if (i == 0)
			std::cout << i + 1 << ". Cash ->\t\t" << income[0] << '\n';
		else if (i == 1)
			std::cout << i + 1 << ". Debet card ->\t" << income[1] << '\n';
		else if (i == 2)
			std::cout << i + 1 << ". Credit card ->\t" << income[2] << '\n';

	int payment_choice = 0;
	std::cin >> payment_choice;
	while (payment_choice <= 0 || payment_choice > 3) {
		std::cout << "Wrong choice. Make your choice correctly: ";
		std::cin >> payment_choice;
	}
	payment_choice--;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
#pragma endregion

#pragma region check_amount
	int amount = 0;
	std::cout << "Enter expense amount -> ";
	std::cin >> amount;
	while (amount < 0 || amount > income[payment_choice]) {
		std::cout << "Try again. Enter expense amount correctly -> ";
		std::cin >> amount;
	}
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
#pragma endregion

#pragma region expense_chrono
	std::cout << "Enter the operation number that you want proceed" << '\n';
	print_map_key();

	unsigned short expense_operation = 0;
	std::cin >> expense_operation;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	std::string exp_note = "none";
	std::cout << "Enter your note about expense -> ";
	getline(std::cin, exp_note);

	income[payment_choice] -= amount;

	Date date_ex;
	date_ex.add_date();

	std::string expense_file_path = folder_path + "/expense_crono.txt";
	std::ofstream out;	
	out.open(expense_file_path, std::ios::app);

	if (out.is_open()) {
		if (expense_operation == 1) {
			expense["loans"] = amount;
			out
				<< date_ex.Get_Day() << "-" << date_ex.Get_Month() << "-" << date_ex.Get_Year() << '\n'
				<< "loans" << '\n'
				<< "Currency - USD" << '\n'
				<< expense["loans"] << '\n'
				<< exp_note << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (expense_operation == 2) {
			expense["monthly_demand"] = amount;
			out
				<< date_ex.Get_Day() << "-" << date_ex.Get_Month() << "-" << date_ex.Get_Year() << '\n'
				<< "monthly_demand" << '\n'
				<< "Currency - USD" << '\n'
				<< expense["monthly_demand"] << '\n'
				<< exp_note << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (expense_operation == 3) {
			expense["others"] = amount;
			out
				<< date_ex.Get_Day() << "-" << date_ex.Get_Month() << "-" << date_ex.Get_Year() << '\n'
				<< "others" << '\n'
				<< "Currency - USD" << '\n'
				<< expense["others"] << '\n'
				<< exp_note << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (expense_operation == 4) {
			expense["phone"] = amount;
			out
				<< date_ex.Get_Day() << "-" << date_ex.Get_Month() << "-" << date_ex.Get_Year() << '\n'
				<< "phone" << '\n'
				<< "Currency - USD" << '\n'
				<< expense["phone"] << '\n'
				<< exp_note << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (expense_operation == 5) {
			expense["transport"] = amount;
			out
				<< date_ex.Get_Day() << "-" << date_ex.Get_Month() << "-" << date_ex.Get_Year() << '\n'
				<< "transport" << '\n'
				<< "Currency - USD" << '\n'
				<< expense["transport"] << '\n'
				<< exp_note << '\n'
				<< "-----------------------------" << '\n';
		}
		else if (expense_operation == 6) {
			expense["utilities"] = amount;
			out
				<< date_ex.Get_Day() << "-" << date_ex.Get_Month() << "-" << date_ex.Get_Year() << '\n'
				<< "utilities" << '\n'
				<< "Currency - USD" << '\n'
				<< expense["utilities"] << '\n'
				<< exp_note << '\n'
				<< "-----------------------------" << '\n';
		}
		else {
			std::cout << "Wrong choice" << "\n\n";
		}
	}

	out.close();
#pragma endregion

#pragma region Rewriting_INCOME_file
	std::ofstream out_income;
	std::string income_file_path = folder_path + "/income.txt";
	out_income.open(income_file_path);

	if (out_income.is_open()) {
		out_income
			<< income[0] << '\n'
			<< income[1] << '\n'
			<< income[2] << '\n';
	}

	out_income.close();
#pragma endregion
}

void Budget::report_print(std::string folder_path) {

	std::string expense_chrono_path = folder_path + "/expense_crono.txt";

	Date random_date;
	std::cout << "Enter the date that you want get info" << '\n';
	random_date.add_date();
	int day_count = random_date.date_converter(random_date.Get_Day(), random_date.Get_Month(), random_date.Get_Year());

	std::cout 
		<< "Choose the operation number that you will get info" << '\n'
		<< "1. Get info for the current day" << '\n'
		<< "2. Get info for a week" << '\n'
		<< "3. Get info for a month" << '\n';;

	unsigned short getinfo_operation = 0;
	std::cin >> getinfo_operation;
	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	std::string file_name;
	std::string text_buffer;
	std::string searched_report;
	std::string recycle;

	std::ifstream in;
	in.open(expense_chrono_path);

	if (getinfo_operation == 1) {
		file_name = "/daily.txt";
		if (in.is_open()) {
			while (getline(in, text_buffer)) {
				if (day_count == days_return(text_buffer)) {

					searched_report += (text_buffer + '\n');

					for (size_t i = 0; i < 5; i++) {
						getline(in, text_buffer);
						searched_report += (text_buffer + '\n');
					}
				}
				else {
					for (size_t i = 0; i < 5; i++) {
						getline(in, recycle);
					}
				}
			}

			std::cout << "Daily file was created in your folder" << "\n\n";
		}
	}
	else if (getinfo_operation == 2) {
		file_name = "/weekly.txt";
		if (in.is_open()) {
			while (getline(in, text_buffer)) {
				if (day_count <= days_return(text_buffer) && days_return(text_buffer) <= day_count + 7) {

					searched_report += (text_buffer + '\n');

					for (size_t i = 0; i < 5; i++) {
						getline(in, text_buffer);
						searched_report += (text_buffer + '\n');
					}
				}
				else {
					for (size_t i = 0; i < 5; i++) {
						getline(in, recycle);
					}
				}
			}

			std::cout << "Weekly file was created in your folder" << "\n\n";
		}
	}
	else if (getinfo_operation == 3) {
		file_name = "/monthly.txt";
		if (in.is_open()) {
			while (getline(in, text_buffer)) {
				if (day_count <= days_return(text_buffer) && days_return(text_buffer) <= day_count + 30) {

					searched_report += (text_buffer + '\n');

					for (size_t i = 0; i < 5; i++) {
						getline(in, text_buffer);
						searched_report += (text_buffer + '\n');
					}
				}
				else {
					for (size_t i = 0; i < 5; i++) {
						getline(in, recycle);
					}
				}
			}

			std::cout << "Monthly file was created in your folder" << "\n\n";
		}
	}
	else {
		std::cout << "wrong choice" << "\n\n";
	}

	in.close();

	std::string report_path = folder_path + file_name;
	std::ofstream out;
	out.open(report_path);

	if (out.is_open()) {
		out << searched_report;
	}
	out.close();
}

void Budget::rating_print(std::string folder_path) {
	std::string expense_chrono_path = folder_path + "/expense_crono.txt";

	Date random_date;
	std::cout << "Enter the date that you want get info" << '\n';
	random_date.add_date();
	int day_count = random_date.date_converter(random_date.Get_Day(), random_date.Get_Month(), random_date.Get_Year());

	std::cout
		<< "Choose the operation number that you will get info" << '\n'
		<< "1. Get rating info for a week" << '\n'
		<< "2. Get rating info for a month" << '\n';;

	unsigned short getinfo_operation = 0;
	std::cin >> getinfo_operation;

	std::cout << "Enter any amount that you want search expenses bigger than this -> ";
	int amount_for_rate = 0;
	std::cin >> amount_for_rate;
	while (amount_for_rate < 0) {
		std::cout << "Try again. Enter amount correctly -> ";
		std::cin >> amount_for_rate;
	}

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');

	std::string file_name;
	std::string text_buffer;
	std::string temp_buffer;
	std::string searched_rating;
	std::string recycle;

	std::ifstream in;
	in.open(expense_chrono_path);

	if (getinfo_operation == 1) {
		file_name = "/weekly_rating.txt";
		if (in.is_open()) {
			while (getline(in, text_buffer)) {
				if (day_count <= days_return(text_buffer) && days_return(text_buffer) <= day_count + 7) {

					temp_buffer += (text_buffer + '\n');

					for (size_t i = 0; i < 2; i++) {
						getline(in, text_buffer);
						temp_buffer += (text_buffer + '\n');
					}

					getline(in, text_buffer);

					if (stoi(text_buffer) >= amount_for_rate) {
						temp_buffer += (text_buffer + '\n');
						for (size_t i = 0; i < 2; i++) {
							getline(in, text_buffer);
							temp_buffer += (text_buffer + '\n');
						}

						searched_rating += temp_buffer;
						temp_buffer = "";
					}
					else {
						temp_buffer = "";
						for (size_t i = 0; i < 2; i++) {
							getline(in, recycle);
						}
					}
				}
				else {
					for (size_t i = 0; i < 5; i++) {
						getline(in, recycle);
					}
				}
			}

			std::cout << "Weekly rating file was created in your folder" << "\n\n";
		}
	}
	else if (getinfo_operation == 2) {
		file_name = "/monthly_rating.txt";
		if (in.is_open()) {
			while (getline(in, text_buffer)) {
				if (day_count <= days_return(text_buffer) && days_return(text_buffer) <= day_count + 30) {

					temp_buffer += (text_buffer + '\n');

					for (size_t i = 0; i < 2; i++) {
						getline(in, text_buffer);
						temp_buffer += (text_buffer + '\n');
					}

					getline(in, text_buffer);

					if (stoi(text_buffer) >= amount_for_rate) {
						temp_buffer += (text_buffer + '\n');
						for (size_t i = 0; i < 2; i++) {
							getline(in, text_buffer);
							temp_buffer += (text_buffer + '\n');
						}

						searched_rating += temp_buffer;
						temp_buffer = "";
					}
					else {
						temp_buffer = "";
						for (size_t i = 0; i < 2; i++) {
							getline(in, recycle);
						}
					}
				}
				else {
					for (size_t i = 0; i < 5; i++) {
						getline(in, recycle);
					}
				}
			}
			std::cout << "Monthly rating file was created in your folder" << "\n\n";
		}
	}
	else {
		std::cout << "wrong choice" << "\n\n";
	}

	in.close();

	std::string rating_path = folder_path + file_name;
	std::ofstream out;
	out.open(rating_path);

	if (out.is_open()) {
		out << searched_rating;
	}
	out.close();
}