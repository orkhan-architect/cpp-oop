#pragma once
#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <direct.h>
#include <sys/stat.h>
#include "sha256.h"
#include "budget.h"

class Users {
private:
	std::string NSP;
	std::string login;
	std::string password;
	std::string slogan;
	bool in_session;
	Budget user_budget;

public:
	Users();

	void fst_out();
	void fst_in(std::string);
	void registration();
	void edit_NSP();
	void edit_slogan();
	void edit_password();
	void pass_recovery();
	void login_operation();
};