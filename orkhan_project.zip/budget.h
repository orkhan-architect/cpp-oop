#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <sys/stat.h>
#include <map>
#include <vector>
#include "dater.h"

class Budget {
private:
	size_t* income;
	std::map<std::string, size_t> expense;

public:
	Budget();

	int days_return(std::string);
	void upload_income(std::string);
	void increase_income(std::string);
	void print_map_key();
	void expense_controlling(std::string);
	void report_print(std::string);
	void rating_print(std::string);
};