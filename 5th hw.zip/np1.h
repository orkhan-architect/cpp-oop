#pragma once

class Fraction {
private:
	int numerator;
	int denominator;
public:
#pragma region Getters
	int Get_Numerator() const { return numerator; }
	int Get_Deniminator() const { return denominator; }
#pragma endregion

	int GCD(int numerator, int denominator);
	int LCM(int denom_1, int denom_2);
	void cleaner(int divider);
	void print();

	Fraction();
	Fraction(int numerator, int denominator);
#pragma region Operators
	void operator + (const Fraction& second_frac) {
		int first_denominator = this->denominator;
		int second_denominator = second_frac.denominator;
		int lcm = LCM(first_denominator, second_denominator);
		int result = (lcm / first_denominator) * this->numerator + (lcm / second_denominator) * second_frac.numerator;
		std::cout << "The created fraction is: " << result << '/' << lcm << '\n';
	}
	void operator - (const Fraction& second_frac) {
		int first_denominator = this->denominator;
		int second_denominator = second_frac.denominator;
		int lcm = LCM(first_denominator, second_denominator);
		int result = (lcm / first_denominator) * this->numerator - (lcm / second_denominator) * second_frac.numerator;
		
		int gcd = GCD(result, lcm);
		result /= gcd;
		lcm /= gcd;

		std::cout << "The created fraction is: " << result << '/' << lcm << '\n';
	}
	void operator * (const Fraction& second_frac) {
		int first_numerator = this->numerator;
		int first_denominator = this->denominator;

		int second_numerator = second_frac.numerator;
		int second_denominator = second_frac.denominator;

		int last_numerator = first_numerator * second_numerator;
		int last_denominator = first_denominator * second_denominator;

		if ((last_numerator > 0 && last_denominator < 0) || (last_numerator < 0 && last_denominator < 0)) {
			last_numerator *= -1;
			last_denominator *= -1;
		}
		int gcd = GCD(last_numerator, last_denominator);
		last_numerator /= gcd;
		last_denominator /= gcd;

		std::cout << "The created fraction is: " << last_numerator << '/' << last_denominator << '\n';
	}
	void operator / (const Fraction& second_frac) {
		int first_numerator = this->numerator;
		int first_denominator = this->denominator;

		int second_numerator = second_frac.numerator;
		int second_denominator = second_frac.denominator;

		int last_numerator = first_numerator * first_denominator;
		int last_denominator = second_numerator * second_denominator;

		if ((last_numerator > 0 && last_denominator < 0) || (last_numerator < 0 && last_denominator < 0)) {
			last_numerator *= -1;
			last_denominator *= -1;
		}
		int gcd = GCD(last_numerator, last_denominator);
		last_numerator /= gcd;
		last_denominator /= gcd;

		std::cout << "The created fraction is: " << last_numerator << '/' << last_denominator << '\n';
	}
#pragma endregion
};