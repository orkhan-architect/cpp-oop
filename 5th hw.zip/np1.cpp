#include <iostream>
#include "np1.h"

int Fraction::GCD(int numerator, int denominator)
{
	if (numerator < 0)
		numerator *= -1;

	while (denominator) {
		int temp = denominator;
		denominator = numerator % denominator;
		numerator = temp;
	}
	return numerator;
}

int Fraction::LCM(int denom_1, int denom_2) {
	return (denom_1 * denom_2) / GCD(denom_1, denom_2);
}

void Fraction::cleaner(int divider) {
	numerator /= divider;
	denominator /= divider;
}

void Fraction::print() {
	if (numerator == denominator)
		std::cout << "The created fraction is: 1" << '\n';
	else if (numerator == 0)
		std::cout << "The created fraction is: 0" << '\n';
	else
		std::cout << "The created fraction is: " << numerator << '/' << denominator << '\n';
}

Fraction::Fraction() {
	numerator = 0;
	denominator = 0;
}

Fraction::Fraction(int numerator, int denominator) {
	if ((numerator > 0 && denominator < 0) || (numerator < 0 && denominator < 0)) {
		numerator *= -1;
		denominator *= -1;
	}

	if ((numerator > 0 && denominator > 0) && (numerator > denominator)) {
		numerator %= denominator;
	}
	else if (numerator < 0 && denominator > 0) {
		int tmp = -1 * numerator;
		if (tmp > denominator) {
			numerator %= denominator;
		}
	}
	this->numerator = numerator;
	this->denominator = denominator;
}