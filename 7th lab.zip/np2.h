#pragma once
#include <iostream>

class Person {
private:
	char* name;
	char* surname;
	char* patronymic;
	char* gender;
	unsigned short age;
public:
#pragma region Getters
	char* GetName() const { return name; }
	char* GetSurname() const { return surname; }
	char* GetPatronymic() const { return patronymic; }
	char* GetGender() const { return gender; }
	unsigned short GetAge() const { return age; }
#pragma endregion

	Person() {
		name = nullptr;
		surname = nullptr;
		patronymic = nullptr;
		gender = nullptr;
		age = 0;
	}
	Person(char* name, char* surname, char* patronymic, char* gender, unsigned short age) {
		this->name = name;
		this->surname = surname;
		this->patronymic = patronymic;
		this->gender = gender;
		this->age = age;
	}

	virtual void print() = 0;
};

class Student : public Person {
private:
	char* university;
	char* uni_city;
	char* uni_country;
	unsigned short group_num;
public:
#pragma region Getters
	char* GetUniversity() const { return university; }
	char* GetUniCity() const { return uni_city; }
	char* GetUniCountry() const { return uni_country; }
	unsigned short GetGroupnum() const { return group_num; }
#pragma endregion
	
	Student() {
		university = nullptr;
		uni_city = nullptr;
		uni_country = nullptr;
		group_num = 0;
	}
	Student(char* name, char* surname, char* patronymic, char* gender, unsigned short age, char* university, char* uni_city, char* uni_country, unsigned short group_num) : 
		Person(name, surname, patronymic, gender, age) {
		this->university = university;
		this->uni_city = uni_city;
		this->uni_country = uni_country;
		this->group_num = group_num;
	};
	
	void print() override {
		std::cout
			<< "Name is:" << "\t\t" << GetName() << '\n'
			<< "Surname is:" << "\t\t" << GetSurname() << '\n'
			<< "Patronymic is:" << "\t\t" << GetPatronymic() << '\n'
			<< "Gender is:" << "\t\t" << GetGender() << '\n'
			<< "Age is:" << "\t\t\t" << GetAge() << '\n'
			<< "University is:" << "\t\t\t" << university << '\n'
			<< "City of university is:" << "\t\t" << uni_city << '\n'
			<< "Country of university is:" << "\t" << uni_country << '\n'
			<< "Group number of the student is:" << "\t" << group_num << '\n';
	}
};

class Lector : public Person {
private:
	char* subject;
public:
#pragma region Getters
	char* GetSubject() const { return subject; }
#pragma endregion	
	
	Lector() {
		subject = nullptr;
	}
	Lector(char* name, char* surname, char* patronymic, char* gender, unsigned short age, char* subject) :
		Person(name, surname, patronymic, gender, age) {
		this->subject = subject;
	}

	void print() override {
		std::cout
			<< "Name is:" << "\t\t" << GetName() << '\n'
			<< "Surname is:" << "\t\t" << GetSurname() << '\n'
			<< "Patronymic is:" << "\t\t" << GetPatronymic() << '\n'
			<< "Gender is:" << "\t\t" << GetGender() << '\n'
			<< "Age is:" << "\t\t\t" << GetAge() << '\n'
			<< "Subject is:" << "\t\t" << subject << '\n';
	}
};