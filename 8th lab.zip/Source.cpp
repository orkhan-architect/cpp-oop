#include <iostream>
#include "lab_11.h"

int main()
{
	std::cout << "Array for strings" << '\n';
	Array<char> my_array_1;
	my_array_1.creation();
	my_array_1.fill_array();
	my_array_1.print_array();

	std::cout << std::endl;
	std::cout << "Array for integers" << '\n';

	Array<int> my_array_2;
	my_array_2.creation();
	my_array_2.fill_array();
	my_array_2.print_array();

	std::cout << std::endl;
	std::cout << "Array for floats" << '\n';

	Array<float> my_array_3;
	my_array_3.creation();
	my_array_3.fill_array();
	my_array_3.print_array();

	return 0;
}