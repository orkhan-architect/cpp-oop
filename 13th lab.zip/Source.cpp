#include <iostream>

template <typename T>
class List {
private:
	struct Node {
		T data;
		Node* next = nullptr;
		Node* prev = nullptr;

		Node(T _data) { data = _data; }		
	};
public:
#pragma region FIELDS
	size_t size = 0;
	Node* head = nullptr;
	Node* tail = nullptr;
#pragma endregion

#pragma region CONSTRUCTORS
	~List();
#pragma endregion

#pragma region FUNCTIONS
	void add(T _data);
	void remove();
	void show() const;

	void man_pos_add(T _data, unsigned short position);
	void man_pos_delete(unsigned short position);
	int searching(T _data);
	int replacing(T _data, T _replace);
	void reversing();
#pragma endregion
};

template <typename T>
List<T>::~List()
{
	for (int i = 0; i < size; ++i)
		remove();
}

template <typename T>
void List<T>::add(T _data)
{
	if (Node* node = new Node(_data)) {
		if (head != nullptr)
			head->prev = node;
		
		node->next = head;		
		head = node;
		node->prev = nullptr;
		++size;
	}
}

template <typename T>
void List<T>::remove()
{
	if (head != nullptr) {
		Node* tmp = head->next;
		delete head;
		head = tmp;
		--size;
	}
}

template <typename T>
void List<T>::show() const
{
	Node* current = head;
	while (current != nullptr) {
		std::cout << current->data << ' ';
		current = current->next;
	}
}

template <typename T>
void List<T>::man_pos_add(T _data, unsigned short position)
{
	++size;
	Node* current = head;
	Node* previous = nullptr;
	Node* tmp = nullptr;

	if (position == 0) {
		add(_data);
		return;
	}

	for (size_t i = 0; i < size; i++) {
		if (i == position){
			tmp = new Node(_data);
			if (tmp != nullptr) {
				tmp->next = current;
				tmp->prev = previous;
				if (i != size-1) {
					current->prev = tmp;
				}
				previous->next = tmp;
			}
			break;
		}
		previous = current;
		current = current->next;
	}
}

template <typename T>
void List<T>::man_pos_delete(unsigned short position)
{
	Node* current = head;
	Node* previous = nullptr;
	Node* tmp = nullptr;

	if (position == 0) {
		remove();
		return;
	}

	for (size_t i = 0; i < size; i++) {
		if (i == position) {
			previous->next = current->next;
			if (i != size - 1) {
				tmp->prev = previous;
			}
			delete current;
			break;
		}
		previous = current;
		current = current->next;
		tmp = current->next;
	}
	--size;
}

template <typename T>
int List<T>::searching(T _data)
{
	int position = -1, iters = 0;
	Node* current = head;

	while (current != nullptr) {
		if (_data == current->data) {
			position = iters;
			break;
		}
		current = current->next;
		iters++;
	}

	return position;
}

template <typename T>
int List<T>::replacing(T _data, T _replace)
{
	int counts = 0;
	Node* current = head;

	while (current != nullptr) {
		if (_data == current->data) {
			current->data = _replace;
			counts++;
		}
		current = current->next;
	}
	
	if (counts > 0)
		return counts;
	else
		return -1;
}

template <typename T>
void List<T>::reversing()
{
	Node* current = head;
	Node* next = nullptr;
	Node* prev = nullptr;

	while (current != nullptr) {
		next = current->next;
		current->next = prev;

		prev = current;
		current = next;
	}
	head = prev;
}

int main()
{
	List<int> my_list;

	my_list.add(1);
	my_list.add(2);
	my_list.add(5);
	my_list.add(4);
	my_list.add(5);

	std::cout << "It is first linked list" << std::endl;
	my_list.show();
	std::cout << std::endl;

	my_list.man_pos_add(6, 5);
	my_list.man_pos_add(7, 6);
	my_list.man_pos_add(8, 2);

	std::cout << '\n' << "It is manual edited linked list" << std::endl;
	my_list.show();
	std::cout << std::endl;

	my_list.man_pos_delete(2);
	my_list.man_pos_delete(4);
	my_list.man_pos_delete(1);

	std::cout << '\n' << "It is manual deleted linked list" << std::endl;
	my_list.show();
	std::cout << std::endl;

	int search_res = my_list.searching(7);
	std::cout << std::endl;
	std::cout << "Your searched element position is -> " << search_res << std::endl;

	int replace_res = my_list.replacing(5, 9);
	std::cout << std::endl;
	std::cout << "Your replaced elements count is -> " << replace_res << std::endl;

	std::cout << "It is replaced linked list" << std::endl;
	my_list.show();
	std::cout << std::endl;

	my_list.reversing();

	std::cout << '\n' << "It is reversed linked list" << std::endl;
	my_list.show();
	std::cout << std::endl;

	return 0;
}