#include <iostream>
#include "oop2.h"

int main()
{
	char* my_name = new char[] { "Orkhan" };
	char* my_surname = new char[] { "Tukanov" };
	char* my_patronymic = new char[] { "Muhammed" };
	char* my_gender = new char[] { "male" };
	unsigned short my_age = 34;
	char* my_position = new char[] { "controller" };
	unsigned short my_salary = 1500;
	unsigned short my_experience = 10;

	Employee somebody(my_name, my_surname, my_patronymic, my_gender, my_age, my_position, my_salary, my_experience);

	somebody.print();

	std::cout << '\n' << "----------------" << '\n';
	char* my_meal = new char[] { "kabab" };
	somebody.eat(my_meal);

	std::cout << '\n' << "----------------" << '\n';
	somebody.sleep(8);

	std::cout << '\n' << "----------------" << '\n';
	somebody.rest(3);

	std::cout << '\n' << "----------------" << '\n';
	somebody.walk(5);

	std::cout << '\n' << "----------------" << '\n';
	somebody.work_day();

	std::cout << '\n' << "----------------" << '\n';
	somebody.work_hour(9, 6);

	return 0;
}