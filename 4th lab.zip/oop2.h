#pragma once

class Human {
private:
	char* name;
	char* surname;
	char* patronymic;
	char* gender;
	unsigned short age;

protected:
	char* position;
	unsigned short salary;
	unsigned short experience;

public:
#pragma region Getters
	char* GetName() const { return name; }
	char* GetSurname() const { return surname; }
	char* GetPatronymic() const { return patronymic; }
	char* GetGender() const { return gender; }
	unsigned short GetAge() const { return age; }

	char* GetPosition() const { return position; }
	unsigned short GetSalary() const { return salary; }
	unsigned short GetExperience() const { return experience; }
#pragma endregion

	Human(char* name, char* surname, char* patronymic, char* gender, unsigned short age);
	~Human();
	
	virtual void print() const;

	void eat(char* meal);
	void sleep(unsigned short hour);
	void rest(unsigned short hour);
	void walk(unsigned short distance);
};

class Employee:public Human {
public:
	Employee(char* name, char* surname, char* patronymic, char* gender, unsigned short age, char* position, unsigned short salary, unsigned short experience) :
		Human(name, surname, patronymic, gender, age) 
	{
		this->position = position;
		this->salary = salary;
		this->experience = experience;
	}
	~Employee() { delete this->position; }

	void print() const override
	{
		std::cout
			<< "--------------------------" << '\n'
			<< "The name of person is:" << "\t\t" << this->GetName() << '\n'
			<< "The surname of person is:" << "\t" << this->GetSurname() << '\n'
			<< "The patronymic of person is:" << "\t" << this->GetPatronymic() << '\n'
			<< "The gender of person is:" << "\t" << this->GetGender() << '\n'
			<< "The age of person is:" << "\t\t" << this->GetAge() << '\n'
			<< "The position of person is:" << "\t" << this->position << '\n'
			<< "The salary (AZN) of person is:" << "\t" << this->salary << '\n'
			<< "The EXP (year) of person is:" << "\t" << this->experience << '\n';
	}

	void work_hour(unsigned short st_hour, unsigned short fin_hour) {
		std::cout
			<< "Work starts at " << st_hour << " o clock and ends at " << fin_hour << " o clock." << '\n';
	}
	void work_day() {
		std::cout << "Saturday and Sunday are rest days." << '\n';
	}
};