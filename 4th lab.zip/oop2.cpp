#include <iostream>
#include "oop2.h"

Human::Human(char* name, char* surname, char* patronymic, char* gender, unsigned short age) {
	this->name = name;
	this->surname = surname;
	this->patronymic = patronymic;
	this->gender = gender;
	this->age = age;
}

Human::~Human() {
	delete this->name;
	delete this->surname;
	delete this->patronymic;
	delete this->gender;
}

void Human::print() const {
	std::cout
		<< "--------------------------" << '\n'
		<< "The name of person is:" << "\t\t" << name << '\n'
		<< "The surname of person is:" << "\t" << surname << '\n'
		<< "The patronymic of person is:" << "\t" << patronymic << '\n'
		<< "The gender of person is:" << "\t" << gender << '\n'
		<< "The age of person is:" << "\t\t" << age << '\n';
}

void Human::eat(char* meal) {
	std::cout
		<< this->name << " ate " << meal << " today." << '\n';
}

void Human::sleep(unsigned short hour) {
	std::cout
		<< this->name << " slept " << hour << " hours today." << '\n';
}

void Human::rest(unsigned short hour) {
	std::cout
		<< this->name << " had a rest " << hour << " hours today." << '\n';
}

void Human::walk(unsigned short distance) {
	std::cout
		<< this->name << " walked " << distance << " km today." << '\n';
}