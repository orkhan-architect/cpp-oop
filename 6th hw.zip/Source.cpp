#include <iostream>
#include "np2.h"

int main()
{
	unsigned short operation;
	bool checking = true;

	while (checking) {
		Complex comp_1;
		Complex comp_2;

		std::cout << "Enter numbers for first complex..." << '\n';
		comp_1.add_numbers();

		std::cout << '\n' << "Enter numbers for second complex..." << '\n';
		comp_2.add_numbers();

		std::cout << std::endl;

		comp_1.print();
		comp_2.print();

		std::cout << std::endl;

		std::cout
			<< '\n' << "Enter the operation number that you want proceed: " << '\n'
			<< "1. ADDITION" << '\n'
			<< "2. SUBTRACTION" << '\n'
			<< "3. MULTIPLICATION" << '\n'
			<< "4. DIVISION" << '\n'
			<< "5. EXIT" << '\n';
		std::cin >> operation;
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (operation)
		{
		case 1:
			comp_1 + comp_2;
			std::cout << '\n';
			break;
		case 2:
			comp_1 - comp_2;
			std::cout << '\n';
			break;
		case 3:
			comp_1 * comp_2;
			std::cout << '\n';
			break;
		case 4:
			comp_1 / comp_2;
			std::cout << '\n';
			break;
		case 5:
			checking = false;
			break;
		default:
			std::cout << "You are out of range, try again." << '\n';
			break;
		}
	}

	return 0;
}