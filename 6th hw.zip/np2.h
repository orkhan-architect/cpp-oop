#pragma once

class Complex {
private:
	int number_1;
	int number_2;

public:
#pragma region Getters
	int Get_Num_1() const { return number_1; }
	int Get_Num_2() const { return number_2; }
#pragma endregion

	Complex();

	void add_numbers();
	void print();
#pragma region Operators
	void operator + (const Complex& second_num) {

		int first_number = this->number_1;
		int second_number = this->number_2;

		int third_number = second_num.number_1;
		int fourth_number = second_num.number_2;

		int left_result = first_number + third_number;
		int right_result = second_number + fourth_number;

		std::cout << std::endl;

		if (right_result > 0)
			std::cout << "z1 + z2 = " << left_result << " + " << right_result << "i" << '\n';
		else if (right_result < 0)
			std::cout << "z1 + z2 = " << left_result << ' ' << right_result << "i" << '\n';
		else
			std::cout << "z1 + z2 = " << left_result << '\n';
	}
	void operator - (const Complex& second_num) {

		int first_number = this->number_1;
		int second_number = this->number_2;

		int third_number = second_num.number_1;
		int fourth_number = second_num.number_2;

		int left_result = first_number - third_number;
		int right_result = second_number - fourth_number;

		if (right_result > 0)
			std::cout << "z1 - z2 = " << left_result << " + " << right_result << "i" << '\n';
		else if (right_result < 0)
			std::cout << "z1 - z2 = " << left_result << ' ' << right_result << "i" << '\n';
		else
			std::cout << "z1 - z2 = " << left_result << '\n';
	}
	void operator * (const Complex& second_num) {
		int first_number = this->number_1;
		int second_number = this->number_2;

		int third_number = second_num.number_1;
		int fourth_number = second_num.number_2;

		int left_result = (first_number * third_number - second_number * fourth_number);
		int right_result = (first_number * fourth_number + second_number * third_number);

		if (right_result > 0)
			std::cout << "z1 * z2 = " << left_result << " + " << right_result << "i" << '\n';
		else if (right_result < 0)
			std::cout << "z1 * z2 = " << left_result << ' ' << right_result << "i" << '\n';
		else
			std::cout << "z1 * z2 = " << left_result << '\n';
	}
	void operator / (const Complex& second_num) {
		int first_number = this->number_1;
		int second_number = this->number_2;

		int third_number = second_num.number_1;
		int fourth_number = second_num.number_2;

		int left_result = (first_number * third_number + second_number * fourth_number) / (third_number * third_number + fourth_number * fourth_number);
		int right_result = (second_number * third_number - first_number * fourth_number) / (third_number * third_number + fourth_number * fourth_number);

		if (right_result > 0)
			std::cout << "z1 / z2 = " << left_result << " + " << right_result << "i" << '\n';
		else if (right_result < 0)
			std::cout << "z1 / z2 = " << left_result << ' ' << right_result << "i" << '\n';
		else
			std::cout << "z1 / z2 = " << left_result << '\n';
	}
#pragma endregion
};