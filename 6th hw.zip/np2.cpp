#include <iostream>
#include "np2.h"

Complex::Complex() {
	number_1 = 0;
	number_2 = 0;
}

void Complex::add_numbers() {
	std::cout << "Enter first integer number: ";
	std::cin >> number_1;

	std::cout << "Enter second integer number: ";
	std::cin >> number_2;

	std::cin.clear();
	std::cin.ignore(INT_MAX, '\n');
}

void Complex::print() {
	if (number_2 > 0)
		std::cout << "z = " << number_1 << " + " << number_2 << "i" << '\n';
	else if (number_2 < 0)
		std::cout << "z = " << number_1 << ' ' << number_2 << "i" << '\n';
	else
		std::cout << "z = " << number_1 << '\n';
}