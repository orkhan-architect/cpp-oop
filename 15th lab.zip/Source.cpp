#include <iostream>

template<typename T>
class BinaryTree
{
private:
	struct Node
	{
		Node* parent = nullptr;
		Node* left = nullptr;
		Node* right = nullptr;
		T data{};
	};
	Node* root = nullptr;

public:

	Node* get_root() const { return root; }
	Node* search(const T& _data);
	void insert(const T& _data);
	void print(Node* node);

	T min_result();
	T max_result();
	void remove();
};

template <typename T>
typename BinaryTree<T>::Node* BinaryTree<T>::search(const T& _data)
{
	Node* current = root;

	while (current)	{
		if (current->data == _data)
			return current;
		else if (current->data > _data)
			current = current->left;
		else
			current = current->right;
	}

	return nullptr;
}

template <typename T>
void BinaryTree<T>::insert(const T& _data)
{
	Node* current = root;
	Node* newNode = nullptr;

	if (current == nullptr)	{
		root = new Node;
		root->data = _data;
		return;
	}

	while (current)	{
		if (_data > current->data) {
			if (current->right == nullptr) {
				newNode = new Node();
				newNode->data = _data;
				current->right = newNode;
				newNode->parent = current;
				return;
			}
			current = current->right;
		}
		else if (_data < current->data)	{
			if (current->left == nullptr) {
				newNode = new Node();
				newNode->data = _data;
				current->left = newNode;
				newNode->parent = current;
				return;
			}
			current = current->left;
		}
		else {
			return;
		}
	}
	delete current;
	delete newNode;
}

template <typename T>
void BinaryTree<T>::print(Node* node)
{
	if (node != nullptr) {
		print(node->left);
		std::cout << node->data << ' ';
		print(node->right);
	}
}

template <typename T>
T BinaryTree<T>::min_result() {
	Node* current = root;

	while (current != nullptr) {
		if (current->left != nullptr)
			current = current->left;
		else
			break;
	}

	T result = current->data;

	return result;
}

template <typename T>
T BinaryTree<T>::max_result() {
	Node* current = root;

	while (current != nullptr) {
		if (current->right != nullptr)
			current = current->right;
		else
			break;
	}

	T result = current->data;

	return result;
}

template <typename T>
void BinaryTree<T>::remove()
{
	Node* left_side = root->left;
	Node* right_side = search(max_result());

	while (left_side != nullptr) {
		Node* tmp = left_side->left;
		delete left_side;
		left_side = tmp;
	}
	while (right_side != nullptr) {
		Node* tmp = right_side->left;
		delete right_side;
		right_side = tmp;
	}

	delete root;
}

int main()
{
	BinaryTree<int> tree;

	tree.insert(15);
	tree.insert(11);
	tree.insert(101);
	tree.insert(100);
	tree.insert(16);
	tree.insert(5);

	tree.print(tree.get_root());

	int min_res = 0, max_res = 0;

	min_res = tree.min_result();
	std::cout << '\n' << "Your min result in binary tree is -> " << min_res;

	max_res = tree.max_result();
	std::cout << '\n' << "Your max result in binary tree is -> " << max_res << '\n';

	tree.remove();

	return 0;
}