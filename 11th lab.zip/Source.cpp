#include <iostream>
#include "lab_11.h"

int main()
{
	Array<int> my_array_2;
	my_array_2.creation();
	my_array_2.fill_array();
	my_array_2.print_array();

	std::cout << '\n' << "Your average result is -> " << my_array_2.find_average() << '\n';
	std::cout << '\n' << "Your max number is -> " << my_array_2.find_max() << '\n';
	std::cout << '\n' << "Your min number is -> " << my_array_2.find_min() << '\n';
	my_array_2.searcher();
	my_array_2.sort_array();

	return 0;
}