#pragma once
#include <iostream>

template<typename T>
class Array {
private:
	unsigned short length;
	T* data;
	char* data_c;

public:
#pragma region Getters
	unsigned short Get_Length() const { return length; }
	T* Get_data() const { return data; }
	char* Get_char_data() const { return data_c; }
#pragma endregion

	Array() {
		length = 0;
		data = nullptr;
		data_c = nullptr;
	}

	Array(const Array& copy) {
		this->length = copy.length;
		this->data = copy.data;
		this->data_c = copy.data_c;
	}

	~Array() {
		delete data;
		delete data_c;
	}

	void creation() {
		std::cout << "Enter length of your array: ";
		std::cin >> length;

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		if (typeid(T).name() == typeid(char).name())
			data_c = static_cast<char*>(calloc(length, sizeof(char)));
		else
			data = static_cast<T*>(calloc(length, sizeof(T)));
	}

	void fill_array() {
		if (data != nullptr || data_c != nullptr) {
			if (typeid(T).name() != typeid(char).name()) {
				for (size_t i = 0; i < length; i++) {
					std::cout << "Enter any number: ";
					std::cin >> data[i];
				}
			}
			else {
				std::cout << "Enter any string: ";
				gets_s(data_c, length);
			}
		}
	}

	void print_array() {
		if (data != nullptr || data_c != nullptr) {
			if (typeid(T).name() != typeid(char).name()) {
				T* begin = data;
				T* end = data + length;
				std::cout << "Your result of array is -> ";
				while (begin != end) {
					std::cout << *begin << ' ';
					++begin;
				}
			}
			else {
				std::cout << "Your text is -> " << data_c;
			}
		}

		std::cout << '\n' << "-------------------";
	}

	float find_average() {
		float sum_aver = 0;
		for (size_t i = 0; i < length; i++)
			sum_aver += data[i];

		sum_aver /= length;

		return sum_aver;
	}

	T find_max() {
		T max_num = data[0];
		for (size_t i = 0; i < length; i++)
			if (max_num < data[i])
				max_num = data[i];

		return max_num;
	}

	T find_min() {
		T min_num = data[0];
		for (size_t i = 0; i < length; i++)
			if (min_num > data[i])
				min_num = data[i];

		return min_num;
	}

	void sort_array() {
		T tmp;
		for (size_t i = 0; i < length; i++)	{
			for (size_t j = 0; j < length; j++) {
				if (data[j] > data[(j + 1)] && j < length - 1) {
					tmp = data[j];
					data[j] = data[(j + 1)];
					data[(j + 1)] = tmp;
				}
			}
		}

		std::cout << '\n' << "Your new sorted array is -> ";
		for (size_t i = 0; i < length; i++)
			std::cout << data[i] << ' ';
		std::cout << std::endl;
	}

	void searcher() {
		T elem_search = 0;
		std::cout << '\n' << "Enter any number for searching in your array: ";
		std::cin >> elem_search;

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		for (size_t i = 0; i < length; i++) {
			if (elem_search == data[i]) {
				std::cout << "This element exists in your array" << '\n';
				break;
			}
			else if (i == length-1) {
				std::cout << "This element does not exist in your array" << '\n';
			}
		}
	}

	T operator[] (int i) {
		if (typeid(T).name() != typeid(char).name())
			return data[i];
		else
			return data_c[i];
	}
};