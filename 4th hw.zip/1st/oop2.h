#pragma once

class Book {
private:
	char* author;
	char* name;
	char* publisher;
	unsigned short year;
	unsigned short count;
	unsigned short pages;
public:
#pragma region Getters
	char* GetAuthor() const { return author; }
	char* GetName() const { return name; }
	char* GetPublisher() const { return publisher; }
	unsigned short GetYear() const { return year; }
	unsigned short GetCount() const { return count; }
	unsigned short GetPages() const { return pages; }
#pragma endregion

	void inputs(char* author, char* name, char* publisher, unsigned short year, unsigned short count, unsigned short pages);
	void print() const;
};