#include <iostream>
#include <cstdio>
#include <string.h>
#include "oop2.h"

int main()
{
	Book* my_array = new Book[3]{};

	my_array[0].inputs(
		new char[] {"J.K.Rowling"},
		new char[] {"Harry Potter: Philosophers Stone"},
		new char[] {"Bloomsbury"}, 
		1997,
		50000,
		766);

	my_array[1].inputs(
		new char[] {"J.K.Rowling"},
		new char[] {"Harry Potter: Chamber of Secrets"},
		new char[] {"Bloomsbury"},
		1998,
		52000,
		800);

	my_array[2].inputs(
		new char[] {"J.R.R.Tolkien"},
		new char[] {"The Lord of the Rings"},
		new char[] {"Allen"},
		1954,
		55000,
		9250);

	for (size_t i = 0; i < 3; i++)
		my_array[i].print();

	char* temp = nullptr;

	char* search_author = new char[] {"J.R.R.Tolkien"};
	std::cout << '\n' << "Below you see result of your searched author--------------" << '\n';
	for (size_t i = 0; i < 3; i++) {
		temp = my_array[i].GetAuthor();
		for (size_t j = 0; j < strlen(search_author); j++) {
			if (temp[j] == search_author[j] && j == strlen(search_author)-1) {
				my_array[i].print();
			}
		}
	}

	char* search_publisher = new char[] {"Bloomsbury"};
	std::cout << '\n' << "Below you see result of your searched publisher------------" << '\n';
	for (size_t i = 0; i < 3; i++) {
		temp = my_array[i].GetPublisher();
		for (size_t j = 0; j < strlen(search_publisher); j++) {
			if (temp[j] == search_publisher[j] && j == strlen(search_publisher) - 1) {
				my_array[i].print();
			}
		}
	}

	unsigned short searched_year = 1990;
	std::cout << '\n' << "Below you see result of searched year that books were published since------------" << '\n';
	for (size_t i = 0; i < 3; i++)
		if (my_array[i].GetYear() > searched_year)
			my_array[i].print();

	delete[] my_array;
	delete[] search_author;
	delete[] search_publisher;
	delete[] temp;

	return 0;
}