#include <iostream>
#include "oop2.h"

void Book::inputs(char* author, char* name, char* publisher, unsigned short year, unsigned short count, unsigned short pages) {
	this->author = author;
	this->name = name;
	this->publisher = publisher;
	this->year = year;
	this->count = count;
	this->pages = pages;
}

void Book::print() const {
	std::cout
		<< "--------------------------" << '\n'
		<< "The author of the book is:" << "\t\t\t" << author << '\n'
		<< "The name of the book is:" << "\t\t\t" << name << '\n'
		<< "The publisher of the book is:" << "\t\t\t" << publisher << '\n'
		<< "This book was published in year:" << "\t\t" << year << '\n'
		<< "This book was published in count:" << "\t\t" << count << '\n'
		<< "The pages count of this book is:" << "\t\t" << pages << '\n';
}