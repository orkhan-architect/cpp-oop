#pragma once

class Worker {
private:
	char* name;
	char* surname;
	char* patronymic;
	char* position;
	unsigned short start_year;
	unsigned short salary;
public:
#pragma region Getters
	char* GetName() const { return name; }
	char* GetSurname() const { return surname; }
	char* GetPatronymic() const { return patronymic; }
	char* GetPosition() const { return position; }
	unsigned short GetStartYear() const { return start_year; }
	unsigned short GetSalary() const { return salary; }
#pragma endregion

	void inputs(char* name, char* surname, char* patronymic, char* position, unsigned short start_year, unsigned short salary);
	void print() const;
};