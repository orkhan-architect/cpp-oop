#include <iostream>
#include "oop2.h"

void Worker::inputs(char* name, char* surname, char* patronymic, char* position, unsigned short start_year, unsigned short salary) {
	this->name = name;
	this->surname = surname;
	this->patronymic = patronymic;
	this->position = position;
	this->start_year = start_year;
	this->salary = salary;
}

void Worker::print() const {
	std::cout
		<< "--------------------------" << '\n'
		<< "The worker name is:" << "\t\t\t" << name << '\n'
		<< "The worker surname is:" << "\t\t\t" << surname << '\n'
		<< "The worker patronymic is:" << "\t\t" << patronymic << '\n'
		<< "The worker position is:" << "\t\t\t" << position << '\n'
		<< "The worker started his work in year:" << "\t" << start_year << '\n'
		<< "The worker earns salary USD:" << "\t\t" << salary << '\n';
}