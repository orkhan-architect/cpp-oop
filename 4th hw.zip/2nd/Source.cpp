#include <iostream>
#include <cstdio>
#include <string.h>
#include "oop2.h"

int main()
{
	Worker* my_array = new Worker[3]{};

	my_array[0].inputs(
		new char[] {"Famil"},
		new char[] {"Hasanov"},
		new char[] {"Azer"},
		new char[] {"technic"},
		2007,
		500);

	my_array[1].inputs(
		new char[] {"Hafis"},
		new char[] {"Aliyev"},
		new char[] {"Samad"},
		new char[] {"technic"},
		2008,
		500);

	my_array[2].inputs(
		new char[] {"Saleh"},
		new char[] {"Agayev"},
		new char[] {"Namig"},
		new char[] {"engineer"},
		2015,
		1200);

	for (size_t i = 0; i < 3; i++)
		my_array[i].print();

	char* temp = nullptr;

	char* search_position = new char[] {"technic"};
	std::cout << '\n' << "Below you see result of your searched position------------" << '\n';
	for (size_t i = 0; i < 3; i++) {
		temp = my_array[i].GetPosition();
		for (size_t j = 0; j < strlen(search_position); j++) {
			if (temp[j] == search_position[j] && j == strlen(search_position) - 1) {
				my_array[i].print();
			}
		}
	}

	unsigned short searched_salary = 1000;
	std::cout << '\n' << "Below you see result of searched salary that exceeds------------" << '\n';
	for (size_t i = 0; i < 3; i++)
		if (my_array[i].GetSalary() > searched_salary)
			my_array[i].print();

	unsigned short current_year = 2021;
	std::cout << '\n' << "Below you see result of searched experience year------------" << '\n';
	for (size_t i = 0; i < 3; i++)
		if (current_year - my_array[i].GetStartYear() > 10)
			my_array[i].print();

	delete[] my_array;
	delete[] search_position;
	delete[] temp;

	return 0;
}