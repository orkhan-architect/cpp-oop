#pragma once

class Person {
private:
	char* name;
	char* surname;
	char* patronymic;
	char* gender;
	unsigned short age;

public:
#pragma region Getters

	char* GetName() const { return name; }
	char* GetSurname() const { return surname; }
	char* GetPatronymic() const { return patronymic; }
	char* GetGender() const { return gender; }
	unsigned short GetAge() const { return age; }

#pragma endregion

	Person() {
		name = nullptr;
		surname = nullptr;
		patronymic = nullptr;
		gender = nullptr;
		age = 0;
	}

	~Person() {
		delete name;
		delete surname;
		delete patronymic;
		delete gender;
	}

	void pers_input(char* name, char* surname, char* patronymic, char* gender, unsigned short age) {
		this->name = name;
		this->surname = surname;
		this->patronymic = patronymic;
		this->gender = gender;
		if (age <= 0 || age > 100)
			throw "Age must be greater than zero\n";
		this->age = age;
	}
	void pers_print() {
		std::cout
			<< "Name is:" << "\t\t" << name << '\n'
			<< "Surname is:" << "\t\t" << surname << '\n'
			<< "Patronymic is:" << "\t\t" << patronymic << '\n'
			<< "Gender is:" << "\t\t" << gender << '\n'
			<< "Age is:" << "\t\t\t" << age << '\n';
	}
};

class Student : public Person {
private:
	char* university;
	char* uni_city;
	char* uni_country;
	unsigned short group_num;

public:
#pragma region Getters

	char* GetUniversity() const { return university; }
	char* GetUniCity() const { return uni_city; }
	char* GetUniCountry() const { return uni_country; }
	unsigned short GetGroupnum() const { return group_num; }

#pragma endregion

	Student() {
		university = nullptr;
		uni_city = nullptr;
		uni_country = nullptr;
		group_num = 0;
	}

	~Student() {
		delete university;
		delete uni_city;
		delete uni_country;
	}

	void stu_input(char* university, char* uni_city, char* uni_country, unsigned short group_num) {
		this->university = university;
		this->uni_city = uni_city;
		this->uni_country = uni_country;
		this->group_num = group_num;
	}
	void stu_print() {
		std::cout
			<< "University is:" << "\t\t\t" << university << '\n'
			<< "City of university is:" << "\t\t" << uni_city << '\n'
			<< "Country of university is:" << "\t" << uni_country << '\n'
			<< "Group number of the student is:" << "\t" << group_num << '\n';
	}
};

class Lector : public Person {
private:
	char* subject;
	unsigned short stu_absence;
	unsigned short aver_stu_activity;
	unsigned short stu_exam_result;

public:
#pragma region Getters

	char* GetSubject() const { return subject; }
	unsigned short GetStuAbsence() const { return stu_absence; }
	unsigned short GetStuAverActiv() const { return aver_stu_activity; }
	unsigned short GetStuExamRes() const { return stu_exam_result; }

#pragma endregion	

	Lector() {
		subject = nullptr;
		stu_absence = 0;
		aver_stu_activity = 0;
		stu_exam_result = 0;
	}

	~Lector() {
		delete subject;
	}

	void lec_input(char* subject, unsigned short stu_absence, unsigned short aver_stu_activity, unsigned short stu_exam_result) {
		this->subject = subject;
		if (stu_absence < 0 || stu_absence > 100)
			throw "Absence can not be negative result\n";
		if (aver_stu_activity < 0 || aver_stu_activity > 12)
			throw "Activity can not be negative result\n";
		this->stu_absence = stu_absence;
		this->aver_stu_activity = aver_stu_activity;
		this->stu_exam_result = stu_exam_result;
	}
	void lec_print() {
		std::cout
			<< "Subject is:" << "\t\t\t\t" << subject << '\n'
			<< "Absence of the student is:" << "\t\t" << stu_absence << '\n'
			<< "Average activity of the student is:" << "\t" << aver_stu_activity << '\n'
			<< "Exam result of the student is:" << "\t\t" << stu_exam_result << '\n';
	}
	void exam_access() {
		if (stu_absence > 7 || aver_stu_activity < 8)
			throw "This student does not have access to exam\n";
	}
};