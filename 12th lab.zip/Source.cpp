#include <iostream>
#include "lab_12.h"

int main()
{
	Student student1;

	char* name1 = new char[] { "Orkhan" };
	char* surname1 = new char[] { "Tukanov" };
	char* patronymic1 = new char[] { "Muhammed" };
	char* gender1 = new char[] { "male" };
	unsigned short age1 = -5;
	try {
		student1.pers_input(name1, surname1, patronymic1, gender1, age1);
	}
	catch (const char* err_1) {
		std::cout << err_1 << '\n';
	}

	char* university1 = new char[] { "ASEU" };
	char* uni_city1 = new char[] { "Baki" };
	char* uni_country1 = new char[] { "Azerbaijan" };
	unsigned short group_num1 = 81;
	student1.stu_input(university1, uni_city1, uni_country1, group_num1);

	Lector lector1;

	char* name2 = new char[] { "Elvin" };
	char* surname2 = new char[] { "Azimov" };
	char* patronymic2 = new char[] { "....." };
	char* gender2 = new char[] { "male" };
	unsigned short age2 = 19;
	try {
		lector1.pers_input(name2, surname2, patronymic2, gender2, age2);
	}
	catch (const char* err_1) {
		std::cout << err_1 << '\n';
	}

	char* subject = new char[] { "Economy" };
	unsigned short absence = -2;
	unsigned short activity = 6;
	unsigned short exam = 10;
	try {
		lector1.lec_input(subject, absence, activity, exam);
	}
	catch (const char* err_2) {
		std::cout << err_2 << '\n';
	}

	try {
		lector1.exam_access();
	}
	catch (const char* err_3) {
		std::cout << err_3 << '\n';
	}
	std::cout << std::endl;

	std::cout << "This info belongs to student" << std::endl;
	student1.pers_print();
	std::cout << std::endl;
	std::cout << "This info belongs to lector" << std::endl;
	lector1.pers_print();
	std::cout << std::endl;
	student1.stu_print();
	std::cout << std::endl;
	lector1.lec_print();
	std::cout << std::endl;

	return 0;
}