#include <iostream>
#include "oop1.h"

int main()
{
	point coordinates;

	coordinates.add();
	coordinates.print();

	return 0;
}