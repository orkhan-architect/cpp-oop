#pragma once

struct point
{
private:
	float x;
	float y;
	float z;

public:
#pragma region Getters
	float GetXCoord() {
		return x;
	}
	float GetYCoord() {
		return y;
	}
	float GetZCoord() {
		return z;
	}
#pragma endregion

#pragma region Setters
	void SetXCoord() {
		std::cout << "Enter the X coordinate -> ";
		std::cin >> x;

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		FILE* files;
		fopen_s(&files, "info.txt", "a");

		char* coord_buffer = new char[10]{};
		sprintf_s(coord_buffer, 10, "%.2f", x);
		if (files != nullptr) {
			fputs("The X coordinate is ", files);
			fputs(coord_buffer, files);
			fputs("\n-----------------------\n", files);
		}

		if (files != nullptr)
			fclose(files);

		delete[] coord_buffer;
	}
	void SetYCoord() {
		std::cout << "Enter the Y coordinate -> ";
		std::cin >> y;

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		FILE* files;
		fopen_s(&files, "info.txt", "a");

		char* coord_buffer = new char[10]{};
		sprintf_s(coord_buffer, 10, "%.2f", y);
		if (files != nullptr) {
			fputs("The Y coordinate is ", files);
			fputs(coord_buffer, files);
			fputs("\n-----------------------\n", files);
		}

		if (files != nullptr)
			fclose(files);

		delete[] coord_buffer;
	}
	void SetZCoord() {
		std::cout << "Enter the Z coordinate -> ";
		std::cin >> z;

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		FILE* files;
		fopen_s(&files, "info.txt", "a");

		char* coord_buffer = new char[10]{};
		sprintf_s(coord_buffer, 10, "%.2f", z);
		if (files != nullptr) {
			fputs("The Z coordinate is ", files);
			fputs(coord_buffer, files);
			fputs("\n-----------------------\n", files);
		}

		if (files != nullptr)
			fclose(files);

		delete[] coord_buffer;
	}
#pragma endregion
	void add()
	{
		SetXCoord();
		SetYCoord();
		SetZCoord();
	}

	void print()
	{
		std::cout
			<< "The X Coordinate is:" << "\t\t\t" << x << '\n'
			<< "The Y Coordinate is:" << "\t\t\t" << y << '\n'
			<< "The Z Coordinate is:" << "\t\t\t" << z;

		std::cout << '\n' << "Below you will see info from info.txt file \n";

		FILE* file;
		char* read_buf = new char[1024]{};
		char* temp_buf = new char[1024]{};


		fopen_s(&file, "info.txt", "r");

		if (file != nullptr)
			while (fgets(read_buf, 1024, file))
				strcat_s(temp_buf, 1024, read_buf);

		std::cout << temp_buf;

		if (file != nullptr)
			fclose(file);

		delete[] read_buf;
		delete[] temp_buf;
	}
};
