#pragma once

struct student
{
private:
	char* name = new char[20]{};
	char* surname = new char[20]{};
	char* patronymic = new char[20]{};
	int* birthday = new int[3]{};
	char* phone_num = new char[11]{};
	char* city = new char[20]{};
	char* country = new char[20]{};
	char* university = new char[30]{};
	char* uni_city = new char[20]{};
	char* uni_country = new char[20]{};
	int group_num;

public:
#pragma region Getters
	char* GetName() {
		return name;
	}
	char* GetSurname() {
		return surname;
	}
	char* GetPatronymic() {
		return patronymic;
	}
	int* Getbirthday() {
		return birthday;
	}
	char* GetPhonenum() {
		return phone_num;
	}
	char* GetCity() {
		return city;
	}
	char* GetCountry() {
		return country;
	}
	char* GetUniversity() {
		return university;
	}
	char* GetUniCity() {
		return uni_city;
	}
	char* GetUniCountry() {
		return uni_country;
	}
	int GetGroupnum() {
		return group_num;
	}
#pragma endregion

#pragma region Setters
	void SetName() {
		std::cout << "Enter the name -> ";
		gets_s(name, 20);
	}
	void SetSurname() {
		std::cout << "Enter the surname -> ";
		gets_s(surname, 20);
	}
	void SetPatronymic() {
		std::cout << "Enter the patronymic -> ";
		gets_s(patronymic, 20);
	}
	void Setbirthday() {
		std::cout << "Enter the birthday in sequence step by step (dd.mm.yyyy) ->\n";
		for (size_t i = 0; i < 3; i++)
			std::cin >> birthday[i];
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');
	}
	void SetPhonenum() {
		std::cout << "Enter the phone number -> ";
		gets_s(phone_num, 11);
	}
	void SetCity() {
		std::cout << "Enter the city -> ";
		gets_s(city, 20);
	}
	void SetCountry() {
		std::cout << "Enter the country -> ";
		gets_s(country, 20);
	}
	void SetUniversity() {
		std::cout << "Enter the university -> ";
		gets_s(university, 30);
	}
	void SetUniCity() {
		std::cout << "Enter the city of University -> ";
		gets_s(uni_city, 20);
	}
	void SetUniCountry() {
		std::cout << "Enter the country of University -> ";
		gets_s(uni_country, 20);
	}
	void SetGroupnum() {
		std::cout << "Enter the group number -> ";
		std::cin >> group_num;
	}
#pragma endregion
	void add()
	{
		SetName();
		SetSurname();
		SetPatronymic();
		Setbirthday();
		SetPhonenum();
		SetCity();
		SetCountry();
		SetUniversity();
		SetUniCity();
		SetUniCountry();
		SetGroupnum();
	}

	void print()
	{
		std::cout
			<< "Name is:" << "\t\t\t" << name << '\n'
			<< "Surname is:" << "\t\t\t" << surname << '\n'
			<< "Patronymic is:" << "\t\t\t" << patronymic << '\n'
			<< "Phone number is:" << "\t\t" << phone_num << '\n'
			<< "City is:" << "\t\t\t" << city << '\n'
			<< "Country is:" << "\t\t\t" << country << '\n'
			<< "University is:" << "\t\t\t" << university << '\n'
			<< "City of university is:" << "\t\t" << uni_city << '\n'
			<< "Country of university is:" << "\t" << uni_country << '\n'
			<< "Group number is:" << "\t\t" << group_num << '\n'
			<< "Birthday is:" << "\t\t\t";
		for (size_t i = 0; i < 3; i++)
			std::cout << birthday[i] << ' ';
	}
};
