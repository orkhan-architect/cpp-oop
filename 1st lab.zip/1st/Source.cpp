#include <iostream>
#include "oop1.h"

int main()
{
	student student1;

	student1.add();
	student1.print();

	return 0;
}