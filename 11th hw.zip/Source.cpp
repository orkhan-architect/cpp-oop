#include <iostream>

template <typename T>
class List
{
private:
	struct Node
	{
		T data;
		Node* next;

		Node(T _data) { 
			data = _data;
			next = nullptr;
		}
		Node() { next = nullptr; }
	};

public:
	size_t size;
	Node* head;

	List();
	~List();

	void add(T _data);
	void remove();
	void show() const;
	void reversing();

	Node** head_clone() {
		return &head;
	}

	Node** operator + (List second_list) {
		
		size_t new_size = this->size + second_list.size;

		Node* first_LL_head = head;
		Node* second_LL_head = second_list.head;

		List third_list;
		for (size_t i = 0; i < new_size; i++) {
			if (i < this->size) {
				third_list.add(first_LL_head->data);
				first_LL_head = first_LL_head->next;
			}
			else {
				third_list.add(second_LL_head->data);
				second_LL_head = second_LL_head->next;
			}
		}

		Node* third_LL_head = third_list.head;
		third_list.size = 0;
		second_list.size = 0;

		return &third_LL_head;
	}

	Node** operator * (List second_list) {

		Node* first_LL_head = head;
		Node* second_LL_head = nullptr;

		List third_list;
		
			for (size_t i = 0; i < this->size; i++) {
				second_LL_head = second_list.head;
				for (size_t j = 0; j < second_list.size; j++) {				
					if (first_LL_head->data == second_LL_head->data) {
						third_list.add(first_LL_head->data);
					}
					second_LL_head = second_LL_head->next;
				}
				first_LL_head = first_LL_head->next;
			}

		Node* third_LL_head = third_list.head;
		third_list.size = 0;
		second_list.size = 0;

		return &third_LL_head;
	}
};

template <typename T>
List<T>::List()
{
	size = 0;
	head = nullptr;
}

template <typename T>
List<T>::~List()
{
	for (int i = 0; i < size; ++i)
		remove();
}

template <typename T>
void List<T>::add(T _data)
{
	if (Node* node = new Node(_data)) {
		node->next = head;
		head = node;
		++size;
	}
}

template <typename T>
void List<T>::remove()
{
	if (head != nullptr) {
		Node* tmp = head->next;
		delete head;
		head = tmp;
		--size;
	}
}

template <typename T>
void List<T>::show() const
{
	Node* current = head;

	while (current != nullptr) {
		std::cout << current->data << ' ';
		current = current->next;
	}
}

template <typename T>
void List<T>::reversing()
{
	Node* current = head;
	Node* next = nullptr;
	Node* prev = nullptr;

	while (current != nullptr) {
		next = current->next;
		current->next = prev;

		prev = current;
		current = next;
	}
	head = prev;
}

int main()
{
	List<int> my_list_1;	
	my_list_1.add(1);
	my_list_1.add(2);
	my_list_1.add(3);
	std::cout << "it is main linked list" << '\n';
	my_list_1.show();
	std::cout << std::endl;

	List<int> my_list_2;
	my_list_2.head = *my_list_1.head_clone();
	std::cout << '\n' << "it is cloned linked list" << '\n';
	my_list_2.show();
	std::cout << std::endl;

	List<int> my_list_3;
	my_list_3.add(1);
	my_list_3.add(2);
	my_list_3.add(3);
	my_list_3.add(4);
	std::cout << '\n' << "it is assistant linked list" << '\n';
	my_list_3.show();
	std::cout << std::endl;

	my_list_1.reversing();
	my_list_3.reversing();

	List<int> my_list_4;
	my_list_4.head = *(my_list_1 + my_list_3);
	std::cout << '\n' << "it is concatenated linked list = first LL + second LL" << '\n';
	my_list_4.show();
	my_list_4.size = my_list_1.size + my_list_3.size;
	std::cout << std::endl;

	List<int> my_list_5;
	my_list_5.head = *(my_list_1 * my_list_3);
	std::cout << '\n' << "it is common element linked list from first LL and second LL" << '\n';
	my_list_5.show();
	my_list_5.size = my_list_1.size + my_list_3.size;
	std::cout << std::endl;

	return 0;
}