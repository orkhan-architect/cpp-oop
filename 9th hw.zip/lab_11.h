#pragma once
#include <iostream>
#include "time.h"

template<typename T>
class Array {
private:
	unsigned short length;
	T** data;
	char* data_c;

public:
#pragma region Getters
	unsigned short Get_Length() const { return length; }
	T** Get_data() const { return data; }
	char* Get_char_data() const { return data_c; }
#pragma endregion

	Array() {
		length = 0;
		data = nullptr;
		data_c = nullptr;
	}

	~Array() {
		free(data);
		free(data_c);
	}

	void creation() {
		std::cout << "Enter equal dimensions of your matrix: ";
		std::cin >> length;

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		if (typeid(T).name() == typeid(char).name()) {
			data_c = static_cast<char*>(calloc(length, sizeof(char)));
		}
		else {
			data = static_cast<T**>(calloc(length, sizeof(T*)));
			for (size_t i = 0; i < length; i++)
				data[i] = static_cast<T*>(calloc(length, sizeof(T)));
		}
	}

	void manual_fill_array() {
		if (data != nullptr || data_c != nullptr) {
			if (typeid(T).name() != typeid(char).name()) {
				for (size_t i = 0; i < length; i++) {
					for (size_t j = 0; j < length; j++){
						std::cout << "Enter any number for " << i << ". group -> ";
						std::cin >> data[i][j];
					}
					std::cout << std::endl;
				}
				std::cout << "----------------------" << '\n';
			}
			else {
				std::cout << "Enter any string: ";
				gets_s(data_c, length);
			}
		}
	}

	void random_fill_array() {
		srand(time(NULL));
		if (data != nullptr || data_c != nullptr) {
			if (typeid(T).name() != typeid(char).name()) {
				for (size_t i = 0; i < length; i++)
					for (size_t j = 0; j < length; j++)
						data[i][j] = rand() % 100 + 1;
			}
			else {
				std::cout << "Enter any string: ";
				gets_s(data_c, length);
			}
		}
	}

	void print_array() {
		if (data != nullptr || data_c != nullptr) {
			if (typeid(T).name() != typeid(char).name()) {
				for (size_t i = 0; i < length; i++) {
					for (size_t j = 0; j < length; j++) {
						std::cout << data[i][j] << ' ';
					}
					std::cout << std::endl;
				}
			}
			else {
				std::cout << "Your text is -> " << data_c;
			}
		}

		std::cout << "-------------------" << '\n';
	}

	T find_max() {
		T max_num = data[0][0];
		for (int i = 0; i < length; i++)
			for (int j = 0; j < length; j++)
				if (max_num < data[i][j])
					max_num = data[i][j];

		return max_num;
	}

	T find_min() {
		T min_num = data[0][0];
		for (int i = 0; i < length; i++)
			for (int j = 0; j < length; j++)
				if (min_num > data[i][j])
					min_num = data[i][j];

		return min_num;
	}

#pragma region Operators
	void operator + (const Array& sec_matrix) {
		T** first_matrix = this->data;
		T** second_matrix = sec_matrix.data;
		T** result_matrix = nullptr;

		result_matrix = static_cast<T**>(calloc(length, sizeof(T*)));
		for (size_t i = 0; i < length; i++)
			result_matrix[i] = static_cast<T*>(calloc(length, sizeof(T)));

		for (size_t i = 0; i < length; i++)
			for (size_t j = 0; j < length; j++)
				result_matrix[i][j] = first_matrix[i][j] + second_matrix[i][j];

		std::cout << "It is the sum of your 2 matrices: " << '\n';
		for (size_t i = 0; i < length; i++) {
			for (size_t j = 0; j < length; j++) {
				std::cout << result_matrix[i][j] << ' ';
			}
			std::cout << std::endl;
		}
		std::cout << "---------------------------" << '\n';
	}

	void operator - (const Array& sec_matrix) {
		T** first_matrix = this->data;
		T** second_matrix = sec_matrix.data;
		T** result_matrix = nullptr;

		result_matrix = static_cast<T**>(calloc(length, sizeof(T*)));
		for (size_t i = 0; i < length; i++)
			result_matrix[i] = static_cast<T*>(calloc(length, sizeof(T)));

		for (size_t i = 0; i < length; i++)
			for (size_t j = 0; j < length; j++)
				result_matrix[i][j] = first_matrix[i][j] - second_matrix[i][j];

		std::cout << "It is the subtraction of your 2 matrices: " << '\n';
		for (size_t i = 0; i < length; i++) {
			for (size_t j = 0; j < length; j++) {
				std::cout << result_matrix[i][j] << ' ';
			}
			std::cout << std::endl;
		}
		std::cout << "---------------------------" << '\n';
	}

	void operator * (const Array& sec_matrix) {
		T** first_matrix = this->data;
		T** second_matrix = sec_matrix.data;
		T** result_matrix = nullptr;

		result_matrix = static_cast<T**>(calloc(length, sizeof(T*)));
		for (size_t i = 0; i < length; i++)
			result_matrix[i] = static_cast<T*>(calloc(length, sizeof(T)));

		for (size_t i = 0; i < length; i++)
			for (size_t j = 0; j < length; j++)
				for (size_t k = 0; k < length; k++)
					result_matrix[i][j] += first_matrix[i][k] * second_matrix[k][j];

		std::cout << "It is the multiplication of your 2 matrices: " << '\n';
		for (size_t i = 0; i < length; i++) {
			for (size_t j = 0; j < length; j++) {
				std::cout << result_matrix[i][j] << ' ';
			}
			std::cout << std::endl;
		}
		std::cout << "---------------------------" << '\n';
	}
#pragma endregion
};