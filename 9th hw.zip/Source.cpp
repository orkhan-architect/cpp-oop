#include <iostream>
#include "lab_11.h"

int main()
{
	Array <int> my_array_1;
	my_array_1.creation();
	my_array_1.manual_fill_array();
	my_array_1.print_array();
	std::cout << '\n' << "Your max number is -> " << my_array_1.find_max() << '\n';
	std::cout << '\n' << "Your min number is -> " << my_array_1.find_min() << '\n';

	std::cout << std::endl;

	Array <int> my_array_2;
	my_array_2.creation();
	my_array_2.random_fill_array();
	my_array_2.print_array();
	std::cout << '\n' << "Your max number is -> " << my_array_2.find_max() << '\n';
	std::cout << '\n' << "Your min number is -> " << my_array_2.find_min() << '\n';

	std::cout << std::endl;

	my_array_1 + my_array_2;
	my_array_1 - my_array_2;
	my_array_1 * my_array_2;

	return 0;
}