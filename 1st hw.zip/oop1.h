#pragma once

class fraction
{
private:
	unsigned int numerator;
	unsigned int denominator;

public:
	fraction(unsigned int x, unsigned int y)
	{
		numerator = x;
		denominator = y;
	}

	int gcd(unsigned int num, unsigned int den)
	{
		while(den) {
			unsigned int temp = den;
			den = num % den;
			num = temp;
		}
		return num;
	}

	void cleaner(unsigned short divider)
	{
		numerator /= divider;
		denominator /= divider;
	}

	void print()
	{
		std::cout << "The first created fraction: " << numerator << '/' << denominator << std::endl;
	}

	void addition(unsigned int any_num, unsigned int nume, unsigned int deno)
	{
		nume += any_num * deno;
		std::cout << "New fraction: " << nume << '/' << deno << std::endl;
	}

	void subtraction(unsigned int any_num, unsigned int nume, unsigned int deno)
	{
		nume = any_num * deno - nume;
		std::cout << "New fraction: -" << nume << '/' << deno << std::endl;
	}

	void multiplication(unsigned int any_num, unsigned int nume, unsigned int deno)
	{
		nume *= any_num;
		std::cout << "New fraction: " << nume << '/' << deno << std::endl;
	}

	void division(unsigned int any_num, unsigned int nume, unsigned int deno)
	{
		deno *= any_num;
		std::cout << "New fraction: " << nume << '/' << deno << std::endl;
	}
};
