#include <iostream>
#include "oop1.h"

int main()
{
	unsigned int cislitel, znamenatel, any_number;
	unsigned short operation;
	bool checking = true;

	std::cout << "Enter any integer number bigger than zero for numerator: ";
	std::cin >> cislitel;

	std::cout << "Enter any integer number bigger than zero for denominator: ";
	std::cin >> znamenatel;
	while (znamenatel == 0) {
		std::cout << "Try again. Enter any integer number bigger than zero for denominator: ";
		std::cin >> znamenatel;
	}

	if (cislitel > znamenatel)
		cislitel %= znamenatel;

	fraction parts(cislitel, znamenatel);

	while (checking) {
		
		unsigned short filter = parts.gcd(cislitel, znamenatel);
		parts.cleaner(filter);

		parts.print();

		std::cout << "Enter any integer number  bigger than zero for operation with fraction: ";
		std::cin >> any_number;

		std::cout
			<< "Enter the operation number that you want proceed: " << '\n'
			<< "1. ADDITION" << '\n'
			<< "2. SUBTRACTION" << '\n'
			<< "3. MULTIPLICATION" << '\n'
			<< "4. DIVISION" << '\n'
			<< "5. EXIT" << '\n';

		std::cin >> operation;		

		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');

		switch (operation)
		{
		case 1:
			parts.addition(any_number, cislitel, znamenatel);
			break;
		case 2:
			parts.subtraction(any_number, cislitel, znamenatel);
			break;
		case 3:
			parts.multiplication(any_number, cislitel, znamenatel);
			break;
		case 4:
			parts.division(any_number, cislitel, znamenatel);
			break;
		case 5:
			checking = false;
			break;
		default:
			std::cout << "You are out of range, try again." << std::endl;
			break;
		}
	}

	return 0;
}